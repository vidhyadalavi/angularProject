import { urls } from './url';
import { staticURLs } from './staticURL';

export const environment = {
  production: false,
  host: 'https://ap.appening.xyz',
  ...urls,
  ...staticURLs,
};
