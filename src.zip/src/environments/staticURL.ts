export const staticURLs = {
  imageBasePath: 'uploads/',
}
