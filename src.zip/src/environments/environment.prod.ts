import { staticURLs } from './staticURL';
import { urls } from './url';

export const environment = {
  production: true,
  host: 'https://licenseportal.us/',
  cannabisUrl: 'https://cannabis.licenseportal.us/',
  tradeWasteUrl: `https://tradewaste.licenseportal.us/`,
  /*
  http://35.168.104.80/
  */
  ...urls,
  ...staticURLs
};
