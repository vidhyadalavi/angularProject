import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-send-link',
  templateUrl: './send-link.component.html',
  styleUrls: ['./send-link.component.css']
})
export class SendLinkComponent implements OnInit, OnDestroy {

  public email = '';
  public validationMsg = ''
  public isSubmit = false;
  public type: string;

  private subscription: Subscription = new Subscription();

  constructor(private router: Router, private authService: AuthenticationService, private toasterService: ToastrService, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.subscription.add(this.activatedRoute.queryParams.subscribe((data: any) => {
      this.type = data.type ? data.type : 'applicant';
    }));
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  navigateToSignInPage() {
    this.router.navigate(['auth/sign-in']);
  }

  checkEmail() {
    const regex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    let isValid = regex.test(String(this.email).toLowerCase());
    if (!isValid) {
      this.validationMsg = 'Please enter valid email'
    } else {
      this.validationMsg = '';
    }
  }

  cancelEmail() {
    this.email = '';
    this.validationMsg = '';
    this.isSubmit = false;
    this.navigateToSignInPage();
  }

  submit() {
    if (this.validationMsg != '' || this.email== '') {
      return false;
    }
    if (this.type == 'admin') {
      this.subscription.add(this.authService.sendResetPasswordLinkStaff({email: this.email}).subscribe(data => {
        this.toasterService.success("We have send reset password link to " + this.email);
      }));
    } else {
      this.subscription.add(this.authService.sendPasswordLink({email: this.email}).subscribe(data => {
        this.toasterService.success("We have send reset password link to " + this.email);
      }));
    }
  }


}
