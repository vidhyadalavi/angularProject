import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit, OnDestroy {

  public showPassword = false;
  public passwordResetForm: FormGroup;
  public isSubmit = false;
  public token = '';
  private subscription: Subscription = new Subscription();

  constructor( private fb: FormBuilder,
    private authenticationService: AuthenticationService,
    private toasterService: ToastrService,
    private router: Router,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.initializeResetPasswordForm();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  initializeResetPasswordForm() {
    this.activatedRoute.queryParams.subscribe(path => {
      this.token = path.id
    })
    this.passwordResetForm = this.fb.group({
      password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(30)]],
      confirmPassword: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(30)]]
    });
  }

  get password() { return this.passwordResetForm.get('password') }
  get confirmPassword() { return this.passwordResetForm.get('confirmPassword') }

  showAndHidePassword(showPassword) {
    if (showPassword) {
      this.showPassword = false;
    } else if (!showPassword) {
      this.showPassword = true;
    }
  }

  checkPasswordMatch() {
    let password = this.passwordResetForm.get('password').value;
    let confirmPassword = this.passwordResetForm.get('confirmPassword').value;
    if (password == confirmPassword) {
      this.passwordResetForm.get('confirmPassword').setErrors(null);
      this.passwordResetForm.get('confirmPassword').clearValidators();
      return true
    } else {
      this.passwordResetForm.get('confirmPassword').setErrors({ invalid: true });
      return false;
    }
  }

  resetPassword() {
    this.isSubmit = true;
    let isPasswordMatching = this.checkPasswordMatch();
    if ((this.token == '' || !this.token) && !(this.passwordResetForm.invalid || !isPasswordMatching)) {
      this.toasterService.error('Invalid token');
      return false;
    }
    if (this.passwordResetForm.invalid || !isPasswordMatching) {
      return false;
    }
    this.subscription.add(
      this.authenticationService.resetPassword({
        ...this.passwordResetForm.value,
        token: this.token
      }).subscribe(data => {
        if (data) {
          this.toasterService.success("Password changed successfully")
          this.router.navigate(['auth/sign-in']);
        }
      })
    );
  }

  navigateToSignInPage() {
    this.router.navigate(['auth/sign-in']);
  }

}
