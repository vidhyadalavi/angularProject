import { Router } from '@angular/router';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { ToastrService } from 'ngx-toastr';
import { UsersService } from 'src/app/core/services';
import { appToaster } from 'src/app/configs';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit, OnDestroy {

  public registerForm: FormGroup;
  public isSubmit = false;
  public EMAIL_REGEX = '[a-z0-9!#$%&\'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*';
  public isPasswordVisible = false;
  private subscription: Subscription = new Subscription();

  constructor(private router: Router,  private authenticationService: AuthenticationService,
    private toasterService: ToastrService, private usersService: UsersService,) { }

  ngOnInit() {
    this.authenticationService.logout();
    this.registerFormInitialize()
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  get email() { return this.registerForm.get('email') }
  get password() { return this.registerForm.get('password') }
  get confirm_password() { return this.registerForm.get('confirm_password') }
  get first_name() { return this.registerForm.get('first_name') }
  get last_name() { return this.registerForm.get('last_name') }
  get agree() { return this.registerForm.get('agree') }

  onClickSignIn() {
    this.router.navigate(['auth/sign-in']);
  }

  private registerFormInitialize(): void {
    const formValidations = {
      'first_name': new FormControl('', [
        Validators.required,
        Validators.maxLength(250),
        Validators.minLength(3),
      ]),
      'last_name': new FormControl('', [
        Validators.required,
        Validators.maxLength(250),
        Validators.minLength(3),
      ]),
      'email': new FormControl('', [
        Validators.required,
        Validators.maxLength(250),
        Validators.pattern(this.EMAIL_REGEX)
      ]),
      'password': new FormControl('', [
        Validators.required,
        Validators.minLength(6),
      ]),
      'confirm_password': new FormControl('', [
        Validators.required,
        Validators.minLength(6),
      ]),
      'agree': new FormControl('',[Validators.required]),
    };

    this.registerForm = new FormGroup(formValidations);
  }

  pwdMatchValidator() {
    return this.registerForm.get('password').value === this.registerForm.get('confirm_password').value
      ? false : this.registerForm.get('confirm_password').setErrors({'incorrect': true });
  }

  onSubmit(): boolean {
    this.isSubmit = true;
    if (this.registerForm.invalid) {
      return false;
    }
    const payload = {
      first_name: this.registerForm.value.first_name,
      last_name: this.registerForm.value.last_name,
      email: (this.registerForm.value.email).toLowerCase(),
      password: this.registerForm.value.password,
      confirm_password: this.registerForm.value.confirm_password,
      agree: this.registerForm.value.agree
    }
    console.log("value is ==>",payload)

    return ;
    this.subscription.add(this.usersService.registerUser(payload)

    
      .subscribe((res) => {

        
        if (res.status === 'success') {
          this.toasterService.success(appToaster.registerSuccess, res.message);
          this.router.navigate(['/sign-in']);
          return ;
        } else {
          this.toasterService.error(appToaster.errorHead, res.message);
          return false;
        }
      })
    );
  }

  passwordVisibilityToggle(passwordField: any){
    if(passwordField.type == 'password'){
      this.isPasswordVisible = true;
    }
    if(passwordField.type == 'text'){
      this.isPasswordVisible = false;
    }
  }

}
