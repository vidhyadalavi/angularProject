import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { ToastrService } from 'ngx-toastr';
import { appToaster } from 'src/app/configs';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit, OnDestroy {

  public loginForm: FormGroup;
  public isSubmit: boolean = false;
  public EMAIL_REGEX = "[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*";
  public returnUrl;
  private subscription: Subscription = new Subscription();

  constructor(private router: Router, private authenticationService: AuthenticationService, private toasterService: ToastrService, private route: ActivatedRoute, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {

    this.authenticationService.logout();
    this.authenticationService.loggedOutBs.next(true);
    this.loginForm = new FormGroup(this.formValidations);
    this.activatedRoute.queryParams.subscribe(path => {
      if (path.type == 'admin') {
        this.loginForm.get("isAdmin").setValue(true);
        this.returnUrl = this.route.snapshot.queryParams.returnUrl || 'admin/index';
      } else {
        this.loginForm.get("isAdmin").setValue("");
        this.returnUrl = this.route.snapshot.queryParams.returnUrl || 'user/index';
      }
    })
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  onClickForgotPassword() {
    if (this.loginForm.value.isAdmin) {
      this.router.navigate(['auth/forgot-password/send-link'], { queryParams: { type: 'admin' } });
    } else {
      this.router.navigate(['auth/forgot-password/send-link'], { queryParams: { type: 'applicant' } });
    }
  }

  onClickRegister() {
    this.router.navigate(['auth/register']);
  }

  public formValidations = {
    'email': new FormControl('', [
      Validators.required,
      Validators.maxLength(250),
      Validators.pattern(this.EMAIL_REGEX)
    ]),
    'password': new FormControl('', [
      Validators.required,
      Validators.minLength(6),
    ]),
    
    'isAdmin': new FormControl('', [])
  };

  get email() {
    return this.loginForm.get('email');
  }

  get password() {
    return this.loginForm.get('password');
  }

  onSubmit(): boolean {
    this.isSubmit = true;
    if (this.loginForm.invalid) {
      return false;
    }

    const payload = {
      email: (this.loginForm.value.email).toLowerCase(),
      password: this.loginForm.value.password,
      isAdmin: this.loginForm.value.isAdmin
    }

    let isAdmin = this.loginForm.get('isAdmin').value;

    if (isAdmin) {
      this.subscription.add(this.authenticationService
        .adminLogin(payload)
        .subscribe(res => {
          if (res.status === 'success') {
            this.toasterService.success(appToaster.loginSuccess);
            if (this.returnUrl == 'admin/index') {
              this.router.navigate([this.returnUrl], { queryParams: { type: 1 } });
              return true;
            } else {
              if (this.returnUrl.includes("?")) {
                if (this.returnUrl.split('?')[1].split("=")[0] == 'id') {
                  this.router.navigate([this.returnUrl.split('?')[0]], { queryParams: { id: this.returnUrl.split('?')[1].split("=")[1] } });
                  return true;
                } else if (this.returnUrl.split('?')[1].split("=")[0] == 'type') {
                  this.router.navigate([this.returnUrl.split('?')[0]], { queryParams: { type: this.returnUrl.split('?')[1].split("=")[1] } });
                  return true;
                }
              } else {
                this.router.navigate([this.returnUrl]);
                return true;
              }
            }
          }
        })
      );
    } else {
      this.subscription.add(this.authenticationService
        .login(payload)
        .subscribe(res => {
          if (res.status === 'success') {
            this.authenticationService.loginDetailsBs.next(res.response);
            this.authenticationService.loggedOutBs.next(false);
            this.toasterService.success(appToaster.loginSuccess);
            this.router.navigate([this.returnUrl]);
            return true;
          }
        })
      );
    }
  }

}
