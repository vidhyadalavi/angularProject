import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

@Component({
  selector: 'app-admin-create-password',
  templateUrl: './admin-create-password.component.html',
  styleUrls: ['./admin-create-password.component.css']
})
export class AdminCreatePasswordComponent implements OnInit, OnDestroy {

  public showPassword = false;
  public passwordForm: FormGroup;
  public isSubmit = false;
  public token = '';
  public createPassword: boolean;

  private subscription: Subscription = new Subscription();

  constructor(private fb: FormBuilder,
    private authenticationService: AuthenticationService,
    private toasterService: ToastrService,
    private router: Router,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    const currentUrl = this.router.url;
    if (currentUrl.includes('/auth/admin/create-password')) {
      this.createPassword = true;
    } else if (currentUrl.includes('/auth/admin/reset-password')) {
      this.createPassword = false;
    }
    this.initializeChangePasswordForm();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  initializeChangePasswordForm() {
    this.activatedRoute.queryParams.subscribe(path => {
      this.token = path.id
    })
    this.passwordForm = this.fb.group({
      password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(30)]],
      confirmPassword: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(30)]]
    });
  }

  get password() { return this.passwordForm.get('password') }
  get confirmPassword() { return this.passwordForm.get('confirmPassword') }

  showAndHidePassword(showPassword) {
    if (showPassword) {
      this.showPassword = false;
    } else if (!showPassword) {
      this.showPassword = true;
    }
  }

  createOrResetPassword() {
    this.isSubmit = true;
    let isPasswordMatch = this.checkPasswordMatch();
    if (this.passwordForm.invalid || !isPasswordMatch) {
      return false;
    }
    if ((this.token == '' || !this.token) && !(this.passwordForm.invalid || !isPasswordMatch)) {
      this.toasterService.error('Invalid token');
      return false;
    }
    if (this.createPassword == true) {
      this.subscription.add(this.authenticationService.createStaffPassword({
        password: this.passwordForm.value.password,
        cnfPassword: this.passwordForm.value.confirmPassword,
        token: this.token
      }).subscribe(data => {
        if (data) {
          this.toasterService.success('Password created successfully');
          this.router.navigate(['auth/sign-in'], {queryParams: {type: 'admin'}});
        }
      }));
    } else if (this.createPassword == false) {
      this.subscription.add(this.authenticationService.resetStaffPassword({
        password: this.passwordForm.value.password,
        cnfPassword: this.passwordForm.value.confirmPassword,
        token: this.token
      }).subscribe(data => {
        if (data) {
          this.toasterService.success('Password changed successfully');
          this.router.navigate(['auth/sign-in'], {queryParams: {type: 'admin'}});
        }
      }));
    }

  }

  checkPasswordMatch() {
    let password = this.passwordForm.get('password').value;
    let cnfPassword = this.passwordForm.get('confirmPassword').value;
    if (password == cnfPassword) {
      this.passwordForm.get('confirmPassword').setErrors(null);
      this.passwordForm.get('confirmPassword').clearValidators();
      return true
    } else {
      this.passwordForm.get('confirmPassword').setErrors({ invalid: true });
      return false;
    }
  }

  navigateToSignInPage() {
    this.router.navigate(['auth/sign-in'], {queryParams: {type: 'admin'}});
  }


}
