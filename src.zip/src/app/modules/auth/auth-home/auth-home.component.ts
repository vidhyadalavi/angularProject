import { environment } from 'src/environments/environment';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

@Component({
  selector: 'app-auth-home',
  templateUrl: './auth-home.component.html',
  styleUrls: ['./auth-home.component.css']
})
export class AuthHomeComponent implements OnInit {

  constructor(private router: Router, private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.authenticationService.loggedOutBs.next(false);
  }

  onClickAnyCard(val) {
    if (val == 1) {
      this.router.navigate(['auth/sign-in']);
    } else if (val == 2) {
      window.open(environment.cannabisUrl, '_blank')
    }
  }

}
