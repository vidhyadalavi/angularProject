import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { SendLinkComponent } from './forgot-password/send-link/send-link.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { ResetPasswordComponent } from './forgot-password/reset-password/reset-password.component';
import { AdminCreatePasswordComponent } from './admin-create-password/admin-create-password.component';
import { AuthHomeComponent } from './auth-home/auth-home.component';


const routes: Routes = [
  {
    path: 'home',
    component: AuthHomeComponent
  },
  {
    path: 'sign-in',
    component: SignInComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  },
  {
    path: 'forgot-password/send-link',
    component: SendLinkComponent
  },
  {
    path: 'forgot-password/reset-password',
    component: ResetPasswordComponent
  },
  {
    path: '',
    redirectTo: 'home'
  },

  {
    path: 'admin/create-password',
    component: AdminCreatePasswordComponent
  },
  {
    path: 'admin/reset-password',
    component: AdminCreatePasswordComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule {
  static component = [
    SignInComponent,
    RegisterComponent,
    SendLinkComponent,
    ResetPasswordComponent,
    AdminCreatePasswordComponent,
    AuthHomeComponent
  ]
}
