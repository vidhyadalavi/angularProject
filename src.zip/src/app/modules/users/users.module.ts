import { UserAuthGuard } from './../../core/guards/user-auth.guard';
import { LayoutsModule } from './../../core/layouts.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsersRoutingModule } from './users-routing.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { SharedModule } from 'src/app/shared/modules/shared.module';


@NgModule({
  imports: [
    CommonModule,
    UsersRoutingModule,
    LayoutsModule,
    NgxPaginationModule,
    SharedModule
  ],
  declarations: [UsersRoutingModule.component],
  providers: [
    UserAuthGuard
  ]
})
export class UsersModule { }
