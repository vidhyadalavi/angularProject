import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { settingConfig } from 'src/app/configs';
import { ApplicationService } from 'src/app/core/http/users/application.service';
import { UsersService } from 'src/app/core/services';

@Component({
  selector: 'app-application-premises',
  templateUrl: './application-premises.component.html',
  styleUrls: ['./application-premises.component.css']
})
export class ApplicationPremisesComponent implements OnInit, OnDestroy {

  public settingConfig = settingConfig;
  public isSubmit = false;
  public premisesForm: FormGroup;
  private subscription: Subscription = new Subscription();
  public currentApplication : any = null;
  public hazardousMaterialAddForm: FormGroup
  public hazardousMaterialsList: Array<object> = [];
  public isEdit = false;
  public editHazardousMaterial: Object;
  public addHazardousMaterialFormSubmit = false;
  public addHazardousMaterialId = '1HM';
  public continueBtnClicked = false;

  @ViewChild('addBtn', {static: false}) addBtn;
  @ViewChild('addHazardousMaterial', { static: false }) addHazardousMaterial: ElementRef;

  constructor(private fb: FormBuilder, private applicationService: ApplicationService, private router: Router, private userService: UsersService) { }

  ngOnInit() {
    this.premisesFormInitialize();
    this.hazardousMaterialAddFormInitialize();
    this.currentApplication = this.userService.getCurrentApplication();
    console.log(this.currentApplication)
    //console.log(this.currentApplication.response.renewed_application_details.application_premises_details);
    if (this.currentApplication.response.application_premises_details) {
      this.patchFormValue();
    }
    // else if(this.currentApplication.response.renewed_application_details.application_premises_details){
    //   //console.log()
    //   this.patchFormValueRenew();
    // }
    this.subscription.add(this.userService.checkSaveAndExit().subscribe(data => {
      if (data.isSaveAndExit && data.currentForm == 'premises') {
        this.userService.isSaveAndExit.next({ isSaveAndExit: false, currentForm: null });
        this.onClickContinue(1);
      }
    }));
    this.checkFormChanges();
  }

  ngOnDestroy() {
    if(!this.continueBtnClicked) {
      if (!this.applicationService.getSaveAndExit()) {
        if (this.currentApplication.response.application_premises_details) {
          if (JSON.stringify(this.premisesForm.value) != JSON.stringify(
            {
              fire_suppression_system: this.currentApplication.response.application_premises_details.fire_suppression_system,
              is_watchman_or_guard: this.currentApplication.response.application_premises_details.is_watchman_or_guard,
              is_animals: this.currentApplication.response.application_premises_details.is_animals,
              is_hazadous: this.currentApplication.response.application_premises_details.is_hazadous,
            }
          )) {
            this.onClickContinue(3);
          } else if ( JSON.stringify(this.hazardousMaterialsList) != JSON.stringify(this.currentApplication['response']['hazardous_material_details'])) {
            this.onClickContinue(3);
          }
        }
      }
    } else {
      this.applicationService.setTabChange(false);
    }
    this.premisesFormInitialize();
    this.hazardousMaterialAddFormInitialize();
  }

  premisesFormInitialize() {
    this.premisesForm = this.fb.group({
      fire_suppression_system: ['', [Validators.required]],
      is_watchman_or_guard: ['', [Validators.required]],
      is_animals: ['', [Validators.required]],
      is_hazadous: ['', [Validators.required]],
    });
  }

  patchFormValue() {
    this.premisesForm.patchValue({
      fire_suppression_system: this.currentApplication.response.application_premises_details.fire_suppression_system,
      is_watchman_or_guard: this.currentApplication.response.application_premises_details.is_watchman_or_guard,
      is_animals: this.currentApplication.response.application_premises_details.is_animals,
      is_hazadous: this.currentApplication.response.application_premises_details.is_hazadous,
    })

    // this.hazardousMaterialsList = this.currentApplication['response']['hazardous_material_details'];
    this.hazardousMaterialsList = this.currentApplication['response']['hazardous_material_details'] ? this.currentApplication['response']['hazardous_material_details'].map((arrayElement) => Object.assign({}, arrayElement)) : [];
  }

  patchFormValueRenew() {
    this.premisesForm.patchValue({
      fire_suppression_system: this.currentApplication.response.renewed_application_details.application_premises_details.fire_suppression_system,
      is_watchman_or_guard: this.currentApplication.response.renewed_application_details.application_premises_details.is_watchman_or_guard,
      is_animals: this.currentApplication.response.renewed_application_details.application_premises_details.is_animals,
      is_hazadous: this.currentApplication.response.renewed_application_details.application_premises_details.is_hazadous,
    })

    // this.hazardousMaterialsList = this.currentApplication['response']['hazardous_material_details'];
    this.hazardousMaterialsList = this.currentApplication['response']['hazardous_material_details'] ? this.currentApplication['response']['hazardous_material_details'].map((arrayElement) => Object.assign({}, arrayElement)) : [];
  }

  goToPrevious() {
    this.router.navigate(['user/application/installer']);
  }

  onClickContinue(isSaveAndExit) {
    this.isSubmit = true;
    if (this.premisesForm.invalid) {
      return false;
    }
    const payload = {
      ...this.premisesForm.value,
      'hazardous_material' : this.hazardousMaterialsList,
      'tab' : this.settingConfig.applicationTab[4].value, // 5
      'application_id': this.currentApplication.response.id,
    }
    this.subscription.add(
      this.applicationService.callApplicationAPI(payload).subscribe((data) => {
        this.isSubmit = false;
        // if (!data['response']['application_premises_details']['hazardous_material']) {
        //   data['response']['application_premises_details']['hazardous_material'] = this.hazardousMaterialsList;
        // }
        if (isSaveAndExit == 1) {
          this.router.navigate(['user/index']);
        } else if (isSaveAndExit == 2) {
          this.userService.setCurrentApplication(data);
          this.applicationService.applicationData.next(data);
          this.router.navigate(['user/application/point-of-contact']);
        } else if (isSaveAndExit == 3) {
          this.userService.setCurrentApplication(data);
          this.applicationService.applicationData.next(data);
        }
        this.subscription.unsubscribe();
      })
    );
  }

  hazardousMaterialAddFormInitialize() {
    this.hazardousMaterialAddForm = this.fb.group({
      hazardous_material_type: ['', [Validators.required]],
      hazardous_material_location: ['', [Validators.required]]
    })
  }

  hideModal() {
    this.addHazardousMaterial.nativeElement.click();
  }

  onClickSave() {
    this.addHazardousMaterialFormSubmit = true;
    if (this.hazardousMaterialAddForm.invalid) {
      return false;
    } else {
      this.hideModal();
      this.addHazardousMaterialFormSubmit = false;
      if (this.isEdit) {
        this.isEdit = false;
        this.hazardousMaterialsList.forEach((materialObj) => {
          if (this.editHazardousMaterial['id'] == materialObj['id']) {
            materialObj['hazardous_material_type'] = this.hazardousMaterialAddForm.value.hazardous_material_type;
            materialObj['hazardous_material_location'] = this.hazardousMaterialAddForm.value.hazardous_material_location;
          }
        })
      } else {
          this.hazardousMaterialsList.push({...this.hazardousMaterialAddForm.value, id : this.addHazardousMaterialId});
          this.addHazardousMaterialId = (Number(this.addHazardousMaterialId[0]) + 1) + 'HM';
      }
    }
  }

  hazardousMaterialFormReset() {
    this.hazardousMaterialAddForm.reset();
    this.hazardousMaterialAddForm.get('hazardous_material_type').setValue('');
  }

  onClickActionEdit(material) {
    this.isEdit = true;
    this.editHazardousMaterial = material;
    this.addBtn.nativeElement.click();
    this.hazardousMaterialAddForm.get('hazardous_material_type').setValue(material['hazardous_material_type']);
    this.hazardousMaterialAddForm.get('hazardous_material_location').setValue(material['hazardous_material_location']);
  }

  onClickActionDelete(material) {
    this.hazardousMaterialsList = this.hazardousMaterialsList.filter(function( obj ) {
      return obj['id'] !== material['id'];
    });
  }

  checkFormChanges() {
    this.subscription.add(this.premisesForm.valueChanges.subscribe((data) => {
      if (this.premisesForm.valid) {
        this.applicationService.setTabChange(false);
      } else {
        this.applicationService.setTabChange(true);
      }
    }));
    this.subscription.add(this.hazardousMaterialAddForm.valueChanges.subscribe((data) => {
      if (this.premisesForm.valid && this.hazardousMaterialAddForm.valid) {
        this.applicationService.setTabChange(false);
      } else {
        this.applicationService.setTabChange(true);
      }
    }));
  }

}
