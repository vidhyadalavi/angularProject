import { ToastrService } from 'ngx-toastr';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { settingConfig } from 'src/app/configs';
import { ApplicationService } from 'src/app/core/http/users/application.service';
import { UsersService } from 'src/app/core/services';

@Component({
  selector: 'app-application-where',
  templateUrl: './application-where.component.html',
  styleUrls: ['./application-where.component.css']
})
export class ApplicationWhereComponent implements OnInit, OnDestroy {

  public settingConfig = settingConfig;
  public isSubmit = false;
  public whereForm: FormGroup;
  private subscription: Subscription = new Subscription();
  public currentApplication : any = null;
  public selectedCity = '';
  public selectedAddressId = '';
  public addressList = [];
  public showDropDown = false;
  public address: any;
  public continueBtnClicked = false;
  public googleAddressShow = false;

  constructor(private fb: FormBuilder, private applicationService: ApplicationService, private router: Router, private userService: UsersService, private toasterService: ToastrService) { }

  ngOnInit() {
    this.selectedCity = this.userService.getSelectedCity();
    this.whereFormInitialize();
    this.currentApplication = this.userService.getCurrentApplication();
    if (this.currentApplication.response['location_type']) {
      this.patchFormValue();
      if (this.currentApplication.response['google_address']) {
        this.googleAddressShow = true;
        this.whereForm.get('address').clearValidators();
        this.whereForm.get('address').setErrors(null);
        this.whereForm.get('google_address').setValidators(Validators.required);
        this.whereForm.get('google_address').setErrors({required: true});
      } else {
        this.googleAddressShow = false;
        this.whereForm.get('google_address').clearValidators();
        this.whereForm.get('google_address').setErrors(null);
        this.whereForm.get('address').setValidators(Validators.required);
        this.whereForm.get('address').setErrors({required: true});
      }
    } else {
      this.onSelectLocationType();
      this.onSelectBusinessLicense();
    }
    this.subscription.add(this.userService.checkSaveAndExit().subscribe(data => {
      if (data.isSaveAndExit && data.currentForm == 'where') {
        this.userService.isSaveAndExit.next({ isSaveAndExit: false, currentForm: null });
        this.onClickContinue(1);
      }
    }));
    // this.checkFormChanges();
  }

  ngOnDestroy(){
    if (!this.continueBtnClicked) {
      if (!this.applicationService.getSaveAndExit()) {
        if (this.currentApplication.response['location_type']) {
          if (JSON.stringify(this.whereForm.value) != JSON.stringify(
            {
              locationType: this.currentApplication.response['location_type'],
              building_or_unit_number: this.currentApplication.response['building_or_unit_number'],
              business_license: this.currentApplication.response['business_license'] == 1 ? 1 : 2,
              license_number: this.currentApplication.response['license_number'],
              address: this.currentApplication.response['address'],
              also_know_as: this.currentApplication.response['also_know_as'],
              google_address: this.currentApplication.response['google_address']
            }
          )) {
            this.onClickContinue(3);
          }
        }
      }
    } else {
      this.applicationService.setTabChange(false);
    }
    this.whereFormInitialize();
  }

  whereFormInitialize() {
    this.whereForm = this.fb.group({
      locationType: ['', [Validators.required]],
      building_or_unit_number: [''],
      business_license: [''],
      license_number: [''],
      address: [''],
      also_know_as: [''],
      google_address: ['']
    })
  }

  patchFormValue() {
    this.whereForm.patchValue({
      locationType: this.currentApplication.response['location_type'],
      business_license: this.currentApplication.response['business_license'] == 1 ? 1 : 2,
      building_or_unit_number: this.currentApplication.response['building_or_unit_number'],
      license_number: this.currentApplication.response['license_number'],
      address: this.currentApplication.response['address'],
      also_know_as: this.currentApplication.response['also_know_as'],
      google_address: this.currentApplication.response['google_address']
    });
    this.selectedAddressId = this.currentApplication.response.address_id;
  }

  goToPrevious() {
    this.router.navigate(['user/application/what']);
  }

  onClickContinue(isSaveAndExit) {
    let payload : Object;
    this.isSubmit = true;
    if (this.whereForm.invalid) {
      return false;
    }
    if ((!this.selectedAddressId || this.selectedAddressId == '') && !this.googleAddressShow) {
      this.toasterService.error("Please select address");
      return false;
    }

    if (this.currentApplication.response.location_type) {
      payload = {
        'tab' : this.settingConfig.applicationTab[1].value, // 2
        'application_id': this.currentApplication.response.id,
        'location_type': this.whereForm.value.locationType,
        'address': this.whereForm.value.address,
        'building_or_unit_number': this.whereForm.value.building_or_unit_number,
        'business_license': this.whereForm.value.business_license,
        'license_number': this.whereForm.value.license_number,
        'address_id': this.selectedAddressId ? this.selectedAddressId : null,
        'also_know_as': this.whereForm.value.also_know_as,
        'google_address': this.whereForm.value.google_address
      };
    } else {
        payload = {
          ...this.currentApplication.response,
          'tab' : this.settingConfig.applicationTab[1].value, // 2
          // 'application_id': this.currentApplication.response.id,
          'location_type': this.whereForm.value.locationType,
          'address': this.whereForm.value.address,
          'building_or_unit_number': this.whereForm.value.building_or_unit_number,
          'business_license': this.whereForm.value.business_license,
          'license_number': this.whereForm.value.license_number,
          'address_id': this.selectedAddressId ? this.selectedAddressId : null,
          'also_know_as': this.whereForm.value.also_know_as,
          'google_address': this.whereForm.value.google_address
        };
    }

    this.subscription.add(this.applicationService.callApplicationAPI(payload).subscribe((data) => {
      this.isSubmit = false;
      if (isSaveAndExit == 1) {
        this.router.navigate(['user/index']);
      } else if (isSaveAndExit == 2){
        this.userService.setCurrentApplication(data);
        this.applicationService.applicationData.next(data);
        this.router.navigate(['user/application/alarm-holder']);
      } else if (isSaveAndExit == 3) {
        this.userService.setCurrentApplication(data);
        this.applicationService.applicationData.next(data);
      }
      this.subscription.unsubscribe();
    })
    );
  }

  onSelectLocationType() {
    if (this.whereForm.controls.locationType.value > 3) {
      this.whereForm.get('building_or_unit_number').setValue('');
      this.whereForm.get('building_or_unit_number').clearValidators();
      this.whereForm.get('building_or_unit_number').setErrors(null);
      this.whereForm.get('business_license').setValue('');
      this.whereForm.get('license_number').setValue('');
      this.whereForm.get('business_license').setValidators(Validators.required);
      this.whereForm.get('business_license').setErrors({required: true});
      if (this.currentApplication.response['location_type'] != this.whereForm.controls.locationType.value) {
        this.applicationService.setTabChange(true);
      } else {
        this.applicationService.setTabChange(false);
      }
    } else if (this.whereForm.controls.locationType.value == 3) {
      this.whereForm.get('building_or_unit_number').setValidators(Validators.required);
      this.whereForm.get('building_or_unit_number').setErrors({required: true});
      this.whereForm.get('business_license').clearValidators();
      this.whereForm.get('business_license').setErrors(null);
      this.whereForm.get('business_license').setValue('');
      this.whereForm.get('license_number').setValue('');
      this.whereForm.get('license_number').clearValidators();
      this.whereForm.get('license_number').setErrors(null);
      if (this.currentApplication.response['location_type'] != this.whereForm.controls.locationType.value) {
        this.applicationService.setTabChange(true);
      } else {
        this.applicationService.setTabChange(false);
      }
    } else {
      this.whereForm.get('building_or_unit_number').clearValidators();
      this.whereForm.get('building_or_unit_number').setErrors(null);
      this.whereForm.get('building_or_unit_number').setValue('');
      this.whereForm.get('business_license').clearValidators();
      this.whereForm.get('business_license').setErrors(null);
      this.whereForm.get('business_license').setValue('');
      this.whereForm.get('license_number').setValue('');
      this.whereForm.get('license_number').clearValidators();
      this.whereForm.get('license_number').setErrors(null);

      if (this.currentApplication.response['location_type'] != this.whereForm.controls.locationType.value) {
        this.applicationService.setTabChange(false);
      } else {
        this.applicationService.setTabChange(true);
      }
    }


  }

  onSelectBusinessLicense() {
    if (this.whereForm.controls.business_license.value == 1) {
      this.whereForm.get('license_number').setValidators(Validators.required);
      this.whereForm.get('license_number').setErrors({required: true});
      this.applicationService.setTabChange(true);
    } else {
      this.whereForm.get('license_number').clearValidators();
      this.whereForm.get('license_number').setErrors(null);
      this.applicationService.setTabChange(false);
    }
  }

  searchAddress() {
    let search_string = this.whereForm.get("address").value;
    this.subscription.add(this.applicationService.searchAddress({ search_string, admin_id: this.selectedCity ? this.selectedCity : this.currentApplication.response.city_id }).subscribe(data => {
      this.showDropDown = true;
      this.addressList = data;
    }));
  }

  selectAddress(item) {
    this.googleAddressShow = false;
    this.whereForm.get('google_address').setValue('');
    this.whereForm.get('google_address').clearValidators();
    this.whereForm.get('google_address').setErrors(null);
    this.whereForm.get('address').setValidators(Validators.required);
    this.whereForm.get('address').setErrors({required: true});
    this.showDropDown = false;
    this.selectedAddressId = item.id;
    this.address = item.property_location
    this.whereForm.patchValue({
      address: item.property_location + ' ' + '[SBL - ' + (item.sbl ? item.sbl : '') + "] " + '[QUAL - ' + ((item.qual == "NULL" || (!item.qual)) ? 'REGULAR' : item.qual) + ']'
    });
  }

  checkFormChanges() {
    this.subscription.add(this.whereForm.valueChanges.subscribe((data) => {
      if (this.whereForm.valid) {
        this.applicationService.setTabChange(false);
      } else {
        this.applicationService.setTabChange(true);
      }
    }));
  }

  showSearchAddress() {
    if(this.whereForm.get('address')) {
      this.whereForm.get('address').setValue('');
    }
    this.googleAddressShow = !this.googleAddressShow;
    if (this.googleAddressShow) {
      this.whereForm.get('address').clearValidators();
      this.whereForm.get('address').setErrors(null);
      this.whereForm.get('google_address').setValidators(Validators.required);
      this.whereForm.get('google_address').setErrors({required: true});
    } else {
      this.whereForm.get('google_address').clearValidators();
      this.whereForm.get('google_address').setErrors(null);
      this.whereForm.get('address').setValidators(Validators.required);
      this.whereForm.get('address').setErrors({required: true});
    }
  }

  googleAddress(event) {
    this.whereForm.get('google_address').setValue(event.formatted_address);
    this.whereForm.get('address').setValue('');
    this.selectedAddressId = null;
  }

  // checkIfAddressTyped(event) {
  //   let address = event.target.value;
  //   if (address != '') {
  //     this.whereForm.get('address').setValue('');
  //   }
  // }

}
