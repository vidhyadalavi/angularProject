import { UsersService } from './../../../../core/services/users/users.service';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { settingConfig } from 'src/app/configs';
import { ApplicationService } from 'src/app/core/http/users/application.service';
import * as moment from 'moment';

@Component({
  selector: 'app-application-review',
  templateUrl: './application-review.component.html',
  styleUrls: ['./application-review.component.css']
})
export class ApplicationReviewComponent implements OnInit, OnDestroy {

  public settingConfig = settingConfig;
  public currentApplication = null;
  public burglarInstallerObj: any;
  public fireInstallerObj: any;

  private subscription: Subscription = new Subscription();

  constructor(private router: Router, private applicationService: ApplicationService, private userService: UsersService) {
  }

  ngOnInit() {
    this.subscription.add(
      this.applicationService.obsApplicationData.subscribe((data)=> {
        if (data) {
          this.currentApplication = data;
          this.currentApplication.response.application_installer_details.forEach((installerObj) => {
            if (installerObj.installer_type == 1) {
              this.burglarInstallerObj = {
                installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
                installer_first_name: installerObj.installer_first_name,
                installer_phone: installerObj.installer_phone,
                servcing_company_name: installerObj.servcing_company_name,
                servcing_company_phone: installerObj.servcing_company_phone,
                servcing_company_address: installerObj.servcing_company_address,
                city: installerObj.city,
                state: installerObj.state,
                zip: installerObj.zip,
                alarm_response: installerObj.alarm_response
              }
            } else if (installerObj.installer_type == 2) {
              this.fireInstallerObj = {
                installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
                installer_first_name: installerObj.installer_first_name,
                installer_phone: installerObj.installer_phone,
                servcing_company_name: installerObj.servcing_company_name,
                servcing_company_phone: installerObj.servcing_company_phone,
                servcing_company_address: installerObj.servcing_company_address,
                city: installerObj.city,
                state: installerObj.state,
                zip: installerObj.zip,
                alarm_response: installerObj.alarm_response
              }
            }
          });
        } else {
          this.currentApplication = this.userService.getCurrentApplication();
          this.currentApplication.response.application_installer_details.forEach((installerObj) => {
            if (installerObj.installer_type == 1) {
              this.burglarInstallerObj = {
                installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
                installer_first_name: installerObj.installer_first_name,
                installer_phone: installerObj.installer_phone,
                servcing_company_name: installerObj.servcing_company_name,
                servcing_company_phone: installerObj.servcing_company_phone,
                servcing_company_address: installerObj.servcing_company_address,
                city: installerObj.city,
                state: installerObj.state,
                zip: installerObj.zip,
                alarm_response: installerObj.alarm_response
              }
            } else if (installerObj.installer_type == 2) {
              this.fireInstallerObj = {
                installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
                installer_first_name: installerObj.installer_first_name,
                installer_phone: installerObj.installer_phone,
                servcing_company_name: installerObj.servcing_company_name,
                servcing_company_phone: installerObj.servcing_company_phone,
                servcing_company_address: installerObj.servcing_company_address,
                city: installerObj.city,
                state: installerObj.state,
                zip: installerObj.zip,
                alarm_response: installerObj.alarm_response
              }
            }
          });
        }
      })
    );
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  goToGivenForm(path) {
    this.router.navigate([path]);
  }

}
