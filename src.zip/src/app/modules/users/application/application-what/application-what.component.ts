import { Router } from '@angular/router';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { settingConfig } from 'src/app/configs';
import { ApplicationService } from 'src/app/core/http/users/application.service';
import { UsersService } from 'src/app/core/services';

@Component({
  selector: 'app-application-what',
  templateUrl: './application-what.component.html',
  styleUrls: ['./application-what.component.css']
})
export class ApplicationWhatComponent implements OnInit, OnDestroy {

  public settingConfig = settingConfig;
  public isSubmit = false;
  public whatForm: FormGroup;
  private subscription: Subscription = new Subscription();
  public applicationType: any;
  public currentApplication : any = null;
  public selectedCity = '';
  public continueBtnClicked = false;

  constructor(private fb: FormBuilder, private applicationService: ApplicationService, private router: Router, private userService: UsersService) { }

  ngOnInit() {
    this.whatFormInitialize();
    this.currentApplication = this.userService.getCurrentApplication();
    if(this.currentApplication) {
      this.applicationType = this.currentApplication.response['type_of_what'];
      this.selectedCity = this.currentApplication.response.city_id;
      this.patchFormValue();
    }else {
      this.applicationType = this.settingConfig.what.typeOfWhat[0].value;
      this.selectedCity = this.userService.getSelectedCity();
    }
    this.subscription.add(this.userService.checkSaveAndExit().subscribe(data => {
      if (data.isSaveAndExit && data.currentForm == 'what') {
        this.userService.isSaveAndExit.next({ isSaveAndExit: false, currentForm: null});
        this.createApplication(1);
      }
    }));
    this.checkFormChanges();
  }

  ngOnDestroy() {
    if (!this.continueBtnClicked) {
      if (!this.applicationService.getSaveAndExit()) {
        if (this.currentApplication) {
          if (JSON.stringify(this.whatForm.value) != JSON.stringify({
            permitNumber: this.currentApplication.response['permit_number'],
            permit: this.currentApplication.response['type_of_permit'],
            alarm: this.currentApplication.response['type_of_alarm']
          }) || this.applicationType != this.currentApplication.response['type_of_what']) {
            this.createApplication(3);
          }
        }
      }
    } else {
      this.applicationService.setTabChange(false);
    }
    this.whatFormInitialize();
  }

  whatFormInitialize() {
    this.whatForm = this.fb.group({
      permitNumber: [''],
      permit: ['', [Validators.required]],
      alarm: ['', [Validators.required]]
    });
  }

  patchFormValue() {
    this.whatForm.patchValue({
      permitNumber: this.currentApplication.response['permit_number'],
      permit: this.currentApplication.response['type_of_permit'],
      alarm: this.currentApplication.response['type_of_alarm']
    });
  }

  createApplication(isSaveAndExit) {
    this.isSubmit = true;
    if (this.whatForm.invalid) {
      return false;
    }
    const payload = {
      "tab" : this.settingConfig.applicationTab[0].value, // 1
      "type_of_what": this.applicationType,
      "permit_number": this.whatForm.value.permitNumber,
      "type_of_permit": this.whatForm.value.permit,
      "type_of_alarm": this.whatForm.value.alarm,
      "city_id": this.selectedCity
    }
    if (this.currentApplication && this.currentApplication.response.id) {
      payload['application_id'] = this.currentApplication.response.id;
    }

    if (this.currentApplication && this.currentApplication.response.location_type) {
      this.subscription.add(
        this.applicationService.callApplicationAPI(payload).subscribe((data) => {
          this.isSubmit = false;
          if (isSaveAndExit == 1) {
            this.router.navigate(['user/index']);
          } else if (isSaveAndExit == 2) {
            this.userService.setCurrentApplication(data);
            this.applicationService.applicationData.next(data);
            if (this.currentApplication) {
              if (this.checkPermitTypeForCompleteInstallerDetails(this.whatForm.value.permit)) {
                this.router.navigate(['user/application/installer']);
              } else {
                this.router.navigate(['user/application/where']);
              }
            } else {
              this.router.navigate(['user/application/where']);
            }
          } else if (isSaveAndExit == 3) {
            this.userService.setCurrentApplication(data);
            this.applicationService.applicationData.next(data);
          }
          this.subscription.unsubscribe();
        })
      );
    } else {
      this.isSubmit = false;
      if (isSaveAndExit == 2) {
        this.userService.setCurrentApplication({response: payload});
        this.applicationService.applicationData.next({response: payload});
        if (this.currentApplication) {
          if (this.checkPermitTypeForCompleteInstallerDetails(this.whatForm.value.permit)) {
            this.router.navigate(['user/application/installer']);
          } else {
            this.router.navigate(['user/application/where']);
          }
        } else {
          this.router.navigate(['user/application/where']);
        }
      } else if (isSaveAndExit == 3) {
        this.userService.setCurrentApplication({response: payload});
        this.applicationService.applicationData.next({response: payload});
      }
      this.subscription.unsubscribe();
    }
  }

  selectApplicationType(type) {
    if (type == this.settingConfig.what.typeOfWhat[0].key) {
      this.applicationType = this.settingConfig.what.typeOfWhat[0].value;
      this.whatForm.get('permitNumber').clearValidators();
      this.whatForm.get('permitNumber').setErrors(null);
      this.whatForm.get('permitNumber').setValue('');
      if (this.currentApplication) {
        if (this.applicationType != this.currentApplication.response['type_of_what'] && this.whatForm.invalid) {
          this.applicationService.setTabChange(true);
        } else {
          this.applicationService.setTabChange(false);
        }
      }
    } else if (type == this.settingConfig.what.typeOfWhat[1].key) {
      this.applicationType = this.settingConfig.what.typeOfWhat[1].value;
      this.whatForm.get('permitNumber').setValidators(Validators.required);
      this.whatForm.get('permitNumber').setErrors({required: true});
      if (this.currentApplication) {
        if (this.applicationType != this.currentApplication.response['type_of_what'] && this.whatForm.invalid) {
          this.applicationService.setTabChange(true);
        } else {
          this.applicationService.setTabChange(false);
        }
      }
    }
  }

  checkFormChanges() {
    this.subscription.add(this.whatForm.valueChanges.subscribe((data: any) => {
      if (this.whatForm.valid) {
        this.applicationService.setTabChange(false);
      } else {
        this.applicationService.setTabChange(true);
      }
      if (this.currentApplication) {
        if (data.permit != this.currentApplication.response['type_of_permit'] && (this.checkPermitTypeForCompleteInstallerDetails(data.permit))) {
          this.applicationService.setInstallerFormRouteOnce(true);
        } else {
          this.applicationService.setInstallerFormRouteOnce(false);
        }
        this.applicationService.setPermitType(data.permit);
      }
      this.applicationService.setWhatFormData(data);
    }));
  }

  checkPermitTypeForCompleteInstallerDetails(permitType) {
    let count = 0;
    let loopCount = 0;
    if (permitType == 1) {
      if (this.currentApplication.response.application_installer_details && this.currentApplication.response.application_installer_details.length > 0 ) {
        this.currentApplication.response.application_installer_details.forEach(installerObj => {
          loopCount++;
          if (installerObj.installer_type == 1 && installerObj.installation_date == null) {
            // return true;
            count++;
          }
        });
        if (loopCount == this.currentApplication.response.application_installer_details.length && count > 0 ) {
          return true;
        } else if (loopCount == this.currentApplication.response.application_installer_details.length && count == 0 ) {
          return false;
        }
      }
    } else if (permitType == 2) {
      if (this.currentApplication.response.application_installer_details && this.currentApplication.response.application_installer_details.length > 0 ) {
        this.currentApplication.response.application_installer_details.forEach(installerObj => {
          loopCount++;
          if (installerObj.installer_type == 2 && installerObj.installation_date == null) {
            // return true;
            count++;
          }
        });
        if (loopCount == this.currentApplication.response.application_installer_details.length && count > 0 ) {
          return true;
        } else if (loopCount == this.currentApplication.response.application_installer_details.length && count == 0 ) {
          return false;
        }
      }
    } else if (permitType == 3) {
      if (this.currentApplication.response.application_installer_details && this.currentApplication.response.application_installer_details.length > 0 && (this.currentApplication.response.application_installer_details[0].installation_date == null || this.currentApplication.response.application_installer_details[1].installation_date == null)) {
        return true;
      } else {
        return false
      }
    }
  }

}
