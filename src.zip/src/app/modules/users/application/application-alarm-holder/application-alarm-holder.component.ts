import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { settingConfig } from 'src/app/configs';
import { ApplicationService } from 'src/app/core/http/users/application.service';
import { UsersService } from 'src/app/core/services';

@Component({
  selector: 'app-application-alarm-holder',
  templateUrl: './application-alarm-holder.component.html',
  styleUrls: ['./application-alarm-holder.component.css']
})
export class ApplicationAlarmHolderComponent implements OnInit, OnDestroy {

  public settingConfig = settingConfig;
  public isSubmit = false;
  public alarmHolderForm: FormGroup;
  private subscription: Subscription = new Subscription();
  public currentApplication : any = null;
  public continueBtnClicked = false;

  constructor(private fb: FormBuilder, private applicationService: ApplicationService, private router: Router, private userService: UsersService) { }

  ngOnInit() {
    console.log("call this component===>")
    this.alarmHolderFormInitialize();
    this.currentApplication = this.userService.getCurrentApplication();
    if (this.currentApplication.response.application_alarm_holder_details) {
      this.patchFormValue();
    }else if(this.currentApplication.response.renewed_application_details){
      this.patchFormValuefor_renew();
    }
    this.subscription.add(this.userService.checkSaveAndExit().subscribe(data => {
      if (data.isSaveAndExit && data.currentForm == 'alarm-holder') {
        this.userService.isSaveAndExit.next({ isSaveAndExit: false, currentForm: null });
        this.onClickContinue(1);
      }
    }));
    this.checkFormChanges();
  }

  ngOnDestroy() {
    if (!this.continueBtnClicked) {
      if (!this.applicationService.getSaveAndExit()) {
        if (this.currentApplication.response.application_alarm_holder_details) {
          if (JSON.stringify(this.alarmHolderForm.value) != JSON.stringify(
            {
              email: this.currentApplication.response.application_alarm_holder_details.email,
              first_name: this.currentApplication.response.application_alarm_holder_details.first_name,
              last_name: this.currentApplication.response.application_alarm_holder_details.last_name,
              business: this.currentApplication.response.application_alarm_holder_details.business,
              phone: this.currentApplication.response.application_alarm_holder_details.phone,
              address: this.currentApplication.response.application_alarm_holder_details.address,
              // city: this.currentApplication.response.application_alarm_holder_details.city,
              // state: this.currentApplication.response.application_alarm_holder_details.state,
              // zip: this.currentApplication.response.application_alarm_holder_details.zip
            }
          )) {
            this.onClickContinue(3);
          }
        }
      }
    } else {
      this.applicationService.setTabChange(false);
    }
    this.alarmHolderFormInitialize();
  }

  patchFormValue() {
    console.log("call")
    this.alarmHolderForm.patchValue({
    
      email: this.currentApplication.response.application_alarm_holder_details.email,
      first_name: this.currentApplication.response.application_alarm_holder_details.first_name,
      last_name: this.currentApplication.response.application_alarm_holder_details.last_name,
      business: this.currentApplication.response.application_alarm_holder_details.business,
      phone: this.currentApplication.response.application_alarm_holder_details.phone,
      address: this.currentApplication.response.application_alarm_holder_details.address,
      // city: this.currentApplication.response.application_alarm_holder_details.city,
      // state: this.currentApplication.response.application_alarm_holder_details.state,
      // zip: this.currentApplication.response.application_alarm_holder_details.zip
    });
  }

  patchFormValuefor_renew(){
    this.alarmHolderForm.patchValue({
    email: this.currentApplication.response.renewed_application_details.application_alarm_holder_details.email,
    first_name: this.currentApplication.response.renewed_application_details.application_alarm_holder_details.first_name,
    last_name: this.currentApplication.response.renewed_application_details.application_alarm_holder_details.last_name,
    business: this.currentApplication.response.renewed_application_details.application_alarm_holder_details.business,
    phone: this.currentApplication.response.renewed_application_details.application_alarm_holder_details.phone,
    address: this.currentApplication.response.renewed_application_details.application_alarm_holder_details.address,
    });
  }

  alarmHolderFormInitialize() {
    this.alarmHolderForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      first_name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
      last_name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
      business: ['', []],
      phone: ['', [Validators.required, Validators.minLength(14), Validators.maxLength(14)]],
      address: ['', [Validators.required]],
      // city: ['', [Validators.required]],
      // state: ['', [Validators.required]],
      // zip: ['', [Validators.required]]
    })
  }

  goToPrevious() {
    this.router.navigate(['user/application/where']);
  }

  onClickContinue(isSaveAndExit) {
    this.isSubmit = true;
    if (this.alarmHolderForm.invalid) {
      return false;
    }
    const payload = {
      ...this.alarmHolderForm.value,
      'email': (this.alarmHolderForm.value.email).toLowerCase(),
      'tab' : this.settingConfig.applicationTab[2].value, // 3
      'application_id': this.currentApplication.response.id,
    }
    this.subscription.add(
      this.applicationService.callApplicationAPI(payload).subscribe((data) => {
        this.isSubmit = false;
        if (isSaveAndExit == 1) {
          this.router.navigate(['user/index']);
        } else if (isSaveAndExit == 2){
          this.userService.setCurrentApplication(data);
          this.applicationService.applicationData.next(data);
          this.router.navigate(['user/application/installer']);
        } else if (isSaveAndExit == 3) {
          this.userService.setCurrentApplication(data);
          this.applicationService.applicationData.next(data);
        }
        this.subscription.unsubscribe();
      })
    );
  }

  checkFormChanges() {
    this.subscription.add(this.alarmHolderForm.valueChanges.subscribe((data: any) => {
      // console.log(data);
      if(this.alarmHolderForm.valid) {
        this.applicationService.setTabChange(false);
      } else {
        this.applicationService.setTabChange(true);
      }
    }));
  }

}
