import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { settingConfig } from 'src/app/configs';
import { ApplicationService } from 'src/app/core/http/users/application.service';
import { UsersService } from 'src/app/core/services';
import * as moment from 'moment';
// import { DatepickerDateCustomClasses } from 'ngx-bootstrap/datepicker';


@Component({
  selector: 'app-application-installer',
  templateUrl: './application-installer.component.html',
  styleUrls: ['./application-installer.component.css']
})
export class ApplicationInstallerComponent implements OnInit, OnDestroy {

  // public dateCustomClasses: DatepickerDateCustomClasses[];
  public settingConfig = settingConfig;
  public isSubmit = false;
  public burglarInstallerForm: FormGroup;
  public fireInstallerForm: FormGroup;
  public currentApplication : any = null;
  public installerType = [];
  public maxDate = moment(new Date()).add(50, 'years').toDate();
  public minDate = moment(new Date()).toDate();
  public selectedDate = null;
  public continueBtnClicked = false;
  public burglarInstallerObj: Object;
  public fireInstallerObj: Object;
  public permitType: any;
  public renewApplication: any;

  private subscription: Subscription = new Subscription();

  constructor(private fb: FormBuilder, private applicationService: ApplicationService, private router: Router, private userService: UsersService) { }

  ngOnInit() {
    this.burglarInstallerFormInitialize();
    this.fireInstallerFormInitialize();
    this.installerType = [];
    this.currentApplication = this.userService.getCurrentApplication();
    if (this.currentApplication.response.application_installer_details) {
      this.patchFormValue();
    }
    else if (this.currentApplication.response.renewed_application_details.application_installer_details) {
      this.patchFormValuerenew();
    }
    this.permitType = this.settingConfig.getKeysByName('what', 'typeOfPermit', this.applicationService.getPermitType() ? this.applicationService.getPermitType() : this.currentApplication.response.type_of_permit);
    if (this.permitType.toLowerCase() == 'burglar only') {
      this.installerType.push('Burglar Alarm Installer');
    } else if (this.permitType.toLowerCase() == 'fire only') {
      this.installerType.push('Fire Alarm Installer');
    } else if (this.permitType.toLowerCase() == 'both') {
      this.installerType.push('Burglar Alarm Installer');
      this.installerType.push('Fire Alarm Installer');
    }

    this.subscription.add(this.userService.checkSaveAndExit().subscribe(data => {
      if (data.isSaveAndExit && data.currentForm == 'installer') {
        this.userService.isSaveAndExit.next({ isSaveAndExit: false, currentForm: null });
        this.onClickContinue(1);
      }
    }));
    this.checkFormChanges();
    this.applicationService.setInstallerFormRouteOnce(false);
    //this.renewPermit();
  }

  ngOnDestroy() {
    if (!this.continueBtnClicked) {
      if (!this.applicationService.getSaveAndExit()) {
        if (this.currentApplication.response.application_installer_details.length > 0) {

          if (this.permitType.toLowerCase() == 'both') {
            if (JSON.stringify(this.burglarInstallerForm.value) != JSON.stringify(
              this.burglarInstallerObj
            ) || JSON.stringify(this.fireInstallerForm.value) != JSON.stringify(
              this.fireInstallerObj
            )) {
              this.onClickContinue(3);
            }
          } else if (this.permitType.toLowerCase() == 'burglar only') {
            if (JSON.stringify(this.burglarInstallerForm.value) != JSON.stringify(
              this.burglarInstallerObj
            ) ) {
              this.onClickContinue(3);
            }
          } else if (this.permitType.toLowerCase() == 'fire only') {
            if (JSON.stringify(this.fireInstallerForm.value) != JSON.stringify(
              this.fireInstallerObj
            ) ) {
              this.onClickContinue(3);
            }
          }
        }
      }
    } else {
      this.applicationService.setTabChange(false);
    }
    this.burglarInstallerFormInitialize();
    this.fireInstallerFormInitialize();
  }

  burglarInstallerFormInitialize() {
    this.burglarInstallerForm = this.fb.group({
      installation_date: ['', [Validators.required]],
      installer_first_name: ['', [Validators.required]],
      installer_phone: ['', [Validators.required]],
      servcing_company_name: ['', [Validators.required]],
      servcing_company_phone: ['', [Validators.required]],
      servcing_company_address: ['', [Validators.required]],
      city: ['', [Validators.required]],
      state: ['', [Validators.required]],
      zip: ['', [Validators.required]],
      alarm_response: ['', [Validators.required]]
    });
  }

  fireInstallerFormInitialize() {
    this.fireInstallerForm = this.fb.group({
      installation_date: ['', [Validators.required]],
      installer_first_name: ['', [Validators.required]],
      installer_phone: ['', [Validators.required, Validators.minLength(14), Validators.maxLength(14)]],
      servcing_company_name: ['', [Validators.required]],
      servcing_company_phone: ['', [Validators.required, Validators.minLength(14), Validators.maxLength(14)]],
      servcing_company_address: ['', [Validators.required]],
      city: ['', [Validators.required]],
      state: ['', [Validators.required]],
      zip: ['', [Validators.required]],
      alarm_response: ['', [Validators.required]]
    });
  }

  patchFormValue() {
    console.log(this.currentApplication.response.type_of_permit)
    if (this.currentApplication.response.type_of_permit == 3) {
      this.currentApplication.response.application_installer_details.forEach((installerObj) => {
        console.log(installerObj);
        if (installerObj.installer_type == 1) {
          this.burglarInstallerForm.patchValue({
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          });
          this.burglarInstallerObj = {
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          }
        } 
        else if (installerObj.installer_type == 2) {
          this.fireInstallerForm.patchValue({
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          });
          this.fireInstallerObj = {
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          }
        }
      });

    } else if (this.currentApplication.response.type_of_permit == 1) {
      this.currentApplication.response.application_installer_details.forEach((installerObj) => {
        if (installerObj.installer_type == 1 && installerObj.installation_date != null) {
          this.burglarInstallerForm.patchValue({
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          });console.log(this.burglarInstallerForm.value)
          this.burglarInstallerObj = {
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          }
        }
      });
    } else if (this.currentApplication.response.type_of_permit == 2) {
      this.currentApplication.response.application_installer_details.forEach((installerObj) => {
        if (installerObj.installer_type == 2 && installerObj.installation_date != null) {
          this.fireInstallerForm.patchValue({
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          });
          this.fireInstallerObj = {
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          }
        }
      });
    }
    console.log(this.fireInstallerForm.value);
    console.log(this.fireInstallerObj);
    console.log(this.burglarInstallerForm.value);
    console.log(this.burglarInstallerObj)
  }

  patchFormValuerenew() {
    console.log(this.currentApplication.response.type_of_permit, "hello")
    if (this.currentApplication.response.type_of_permit == 3) {
      this.currentApplication.response.renewed_application_details.application_installer_details.forEach((installerObj) => {
        console.log(installerObj.installer_first_name);
        if (installerObj.installer_type == 1) {
          this.burglarInstallerForm.patchValue({
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response,
            
          });console.log(installerObj.installer_first_name)
          this.burglarInstallerObj = {
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          }
        } 
        else if (installerObj.installer_type == 2) {
          this.fireInstallerForm.patchValue({
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          });
          this.fireInstallerObj = {
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          }
        }
      });

    } else if (this.currentApplication.response.type_of_permit == 1) {
      this.currentApplication.renewed_application_details.application_installer_details.forEach((installerObj) => {
        if (installerObj.installer_type == 1 && installerObj.installation_date != null) {
          this.burglarInstallerForm.patchValue({
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          });
          this.burglarInstallerObj = {
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          }
        }
      });
    } else if (this.currentApplication.response.type_of_permit == 2) {
      this.currentApplication.renewed_application_details.application_installer_details.forEach((installerObj) => {
        if (installerObj.installer_type == 2 && installerObj.installation_date != null) {
          this.fireInstallerForm.patchValue({
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          });
          this.fireInstallerObj = {
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          }
        }
      });
    }

  }

  goToPrevious() {
    this.router.navigate(['user/application/alarm-holder']);
  }

  onClickContinue(isSaveAndExit) {
    this.isSubmit = true;
    if ((this.permitType.toLowerCase() == 'burglar only') && this.burglarInstallerForm.invalid) {
      return false;
    } else if ((this.permitType.toLowerCase() == 'fire only') && this.fireInstallerForm.invalid) {
      return false;
    } else if ((this.permitType.toLowerCase() == 'both') && (this.burglarInstallerForm.invalid || this.fireInstallerForm.invalid)) {
      return false;
    }
    let payload;
    if (this.permitType.toLowerCase() == 'burglar only') {
      payload = {
        'burglar_installer': this.burglarInstallerForm.value,
        'fire_installer': {},
        'tab' : this.settingConfig.applicationTab[3].value, // 4
        'application_id': this.currentApplication.response.id,
      }
    } else if (this.permitType.toLowerCase() == 'fire only') {
      payload = {
        'burglar_installer': {},
        'fire_installer': this.fireInstallerForm.value,
        'tab' : this.settingConfig.applicationTab[3].value, // 4
        'application_id': this.currentApplication.response.id,
      }
    } else if (this.permitType.toLowerCase() == 'both') {
      payload = {
        'burglar_installer': this.burglarInstallerForm.value,
        'fire_installer': this.fireInstallerForm.value,
        'tab' : this.settingConfig.applicationTab[3].value, // 4
        'application_id': this.currentApplication.response.id,
      }
    }
    
    this.subscription.add(
      
      this.applicationService.callApplicationAPI(payload).subscribe((data) => {
        
        this.isSubmit = false;
        if (isSaveAndExit == 1) {
          this.router.navigate(['user/index']);
        } else if (isSaveAndExit == 2) {
          this.userService.setCurrentApplication(data);
          this.applicationService.applicationData.next(data);
          this.router.navigate(['user/application/premises']);
        } else if (isSaveAndExit == 3) {
          this.userService.setCurrentApplication(data);
          this.applicationService.applicationData.next(data);
        }
        this.subscription.unsubscribe();
      })
    );
  }

  prefillFireInstallerDetails() {
    this.fireInstallerForm.patchValue({
      installation_date: moment(new Date(this.burglarInstallerForm.value.installation_date)).format('MM-DD-YYYY'),
      installer_first_name: this.burglarInstallerForm.value.installer_first_name,
      installer_phone: this.burglarInstallerForm.value.installer_phone,
      servcing_company_name: this.burglarInstallerForm.value.servcing_company_name,
      servcing_company_phone: this.burglarInstallerForm.value.servcing_company_phone,
      servcing_company_address: this.burglarInstallerForm.value.servcing_company_address,
      city: this.burglarInstallerForm.value.city,
      state: this.burglarInstallerForm.value.state,
      zip: this.burglarInstallerForm.value.zip,
      alarm_response: this.burglarInstallerForm.value.alarm_response
    });
  }

  handleDateRange(event) {
    this.selectedDate = moment(new Date(event)).format('MM-DD-YYYY');
  }

  checkFormChanges() {
    if (this.currentApplication.response.type_of_permit == 3) {
      this.subscription.add(this.burglarInstallerForm.valueChanges.subscribe((data) => {
        if (this.burglarInstallerForm.valid && this.fireInstallerForm.valid) {
          this.applicationService.setTabChange(false);
          this.applicationService.setBurglarInstallerForm(true);
        } else {
          this.applicationService.setTabChange(true);
          this.applicationService.setBurglarInstallerForm(false);
        }

      }));
      this.subscription.add(this.fireInstallerForm.valueChanges.subscribe((data) => {
        if (this.burglarInstallerForm.valid && this.fireInstallerForm.valid) {
          this.applicationService.setTabChange(false);
          this.applicationService.setFireInstallerForm(true);
        } else {
          this.applicationService.setTabChange(true);
          this.applicationService.setFireInstallerForm(false);
        }

      }));
    } else if (this.currentApplication.response.type_of_permit == 2) {
      this.subscription.add(this.fireInstallerForm.valueChanges.subscribe((data) => {
        if (this.fireInstallerForm.valid) {
          this.applicationService.setTabChange(false);
        } else {
          this.applicationService.setTabChange(true);
        }
        this.applicationService.setFireInstallerForm(data);
      }));
    } else if (this.currentApplication.response.type_of_permit == 1) {
      this.subscription.add(this.burglarInstallerForm.valueChanges.subscribe((data) => {
        // console.log(data);
        if (this.burglarInstallerForm.valid) {
          this.applicationService.setTabChange(false);
        } else {
          this.applicationService.setTabChange(true);
        }
        this.applicationService.setBurglarInstallerForm(data);
      }));
    }
  }

  // renewPermit(){
  //   let payload=this.currentApplication.response.renewed_application_details.application_installer_details;
  //   // if(this.currentApplication.response.renewed_application_details.application_installer_details){

  //   // }
  //   this.userService.renewPermit({payload}).subscribe((res:any)=>{
  //     console.log(res);
  //   })
  // }
}
