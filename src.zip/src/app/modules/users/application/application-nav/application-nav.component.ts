import { Component, OnDestroy, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ApplicationService } from 'src/app/core/http/users/application.service';
import { UsersService } from 'src/app/core/services';

@Component({
  selector: 'app-application-nav',
  templateUrl: './application-nav.component.html',
  styleUrls: ['./application-nav.component.css']
})
export class ApplicationNavComponent implements OnInit, OnDestroy {

  public activeRoute: string;
  public currentApplication = null;

  private subscription: Subscription = new Subscription();

  constructor(private userService: UsersService, private router: Router, private applicationService: ApplicationService) {
    /** GET CURRENT ROUTE */
    this.subscription.add(
      this.router.events.subscribe((event: any) => {
        if (event instanceof NavigationEnd) {
          setTimeout(() => {
            this.currentApplication = this.userService.getCurrentApplication();
            this.activeRoute = event.url.split('/')[ event.url.split('/').length - 1]
            let isPrevFormComplete = this.checkPreviousForm(this.activeRoute);
            if ((!isPrevFormComplete) && this.currentApplication) {
              if (this.currentApplication.response.point_of_contact.length > 0) {
                this.router.navigate(['user/application/review']);
              } else if (this.currentApplication.response.application_premises_details) {
                this.router.navigate(['user/application/point-of-contact']);
              } else if (this.currentApplication.response.application_installer_details.length > 0) {
                this.router.navigate(['user/application/premises']);
              } else if (this.currentApplication.response.application_alarm_holder_details) {
                this.router.navigate(['user/application/installer']);
              } else if (this.currentApplication.response.location_type) {
                this.router.navigate(['user/application/alarm-holder']);
              } else if (this.currentApplication.response.type_of_what) {
                this.router.navigate(['user/application/where']);
              } else {
                this.router.navigate(['user/application/what']);
              }
            }
          }, 0)
        }
      }));
   }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  goToGivenForm(path, formType) {
    console.log("value is==>",this.applicationService.getTabChange())
    if (!this.applicationService.getTabChange()) {

      this.applicationService.setTabChange(false);
      let isPrevFormComplete = this.checkPreviousForm(formType);
      if (isPrevFormComplete === false) {
        return false;
      } else if (isPrevFormComplete == 'installer') {
        this.router.navigate(['user/application/installer']);
      } else {
        this.router.navigate([path]);
      }
    }
  }

  checkPreviousForm(type) {
    this.currentApplication = this.userService.getCurrentApplication();
    if (!this.currentApplication) {
      return false;
    } else if (this.checkPermitTypeForCompleteInstallerDetails(this.applicationService.getPermitType() ? this.applicationService.getPermitType() : this.currentApplication.response.type_of_permit) && (this.applicationService.getInstallerFormRouteOnce())) {
      return 'installer';
    } else {
      if (type == 'what') {
        return true;
      } else if (type == 'where') {
        if (!this.currentApplication.response.type_of_what) {
          return false;
        } else {
          return true;
        }
      } else if (type == 'alarm-holder') {
        if (!this.currentApplication.response.location_type) {
          return false;
        } else {
          return true;
        }
      } else if (type == 'installer') {
        if (!this.currentApplication.response.application_alarm_holder_details) {
          return false;
        } else {
          return true;
        }
      } else if (type == 'premises') {
        if (!(this.currentApplication.response.application_installer_details.length > 0)) {
          return false;
        } else {
          return true;
        }
      } else if (type == 'point-of-contact') {
        if (!this.currentApplication.response.application_premises_details) {
          return false;
        } else {
          return true;
        }
      } else if (type == 'review') {
        if ((!this.currentApplication.response.point_of_contact) || (this.currentApplication.response.point_of_contact.length == 0)) {
          return false;
        } else {
          return true;
        }
      }
    }
  }

  checkPermitTypeForCompleteInstallerDetails(permitType) {
    let count = 0;
    let loopCount = 0;
    if (permitType == 1) {
      if (this.currentApplication.response.application_installer_details && this.currentApplication.response.application_installer_details.length > 0 ) {
        this.currentApplication.response.application_installer_details.forEach(installerObj => {
          loopCount++;
          if (installerObj.installer_type == 1 && installerObj.installation_date == null) {
            // return true;
            count++;
          }
        });
        if (loopCount == this.currentApplication.response.application_installer_details.length && count > 0 ) {
          return true;
        } else if (loopCount == this.currentApplication.response.application_installer_details.length && count == 0 ) {
          return false;
        }
      }
    } else if (permitType == 2) {
      if (this.currentApplication.response.application_installer_details && this.currentApplication.response.application_installer_details.length > 0 ) {
        this.currentApplication.response.application_installer_details.forEach(installerObj => {
          loopCount++;
          if (installerObj.installer_type == 2 && installerObj.installation_date == null) {
            // return true;
            count++;
          }
        });
        if (loopCount == this.currentApplication.response.application_installer_details.length && count > 0 ) {
          return true;
        } else if (loopCount == this.currentApplication.response.application_installer_details.length && count == 0 ) {
          return false;
        }
      }
    } else if (permitType == 3) {
      if (this.currentApplication.response.application_installer_details && this.currentApplication.response.application_installer_details.length > 0 && (this.currentApplication.response.application_installer_details[0].installation_date == null || this.currentApplication.response.application_installer_details[1].installation_date == null)) {
        return true;
      } else {
        return false
      }
    }
  }

}
