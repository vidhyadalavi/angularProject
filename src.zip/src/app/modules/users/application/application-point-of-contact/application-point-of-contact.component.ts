import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, FormArray } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { settingConfig } from 'src/app/configs';
import { ApplicationService } from 'src/app/core/http/users/application.service';
import { UsersService } from 'src/app/core/services';

@Component({
  selector: 'app-application-point-of-contact',
  templateUrl: './application-point-of-contact.component.html',
  styleUrls: ['./application-point-of-contact.component.css']
})
export class ApplicationPointOfContactComponent implements OnInit, OnDestroy {

  public settingConfig = settingConfig;
  public isSubmit = false;
  private subscription: Subscription = new Subscription();
  public currentApplication : any = null;
  public pointOfContactForm: FormGroup;
  public isduplicatePointOfContacts: boolean;
  public continueBtnClicked = false;

  constructor(private fb: FormBuilder, private applicationService: ApplicationService, private router: Router, private userService: UsersService) { }

  ngOnInit() {
    this.pointOfContactFormInitialize();
    this.currentApplication = this.userService.getCurrentApplication();
    if (this.currentApplication.response.point_of_contact.length > 0) {
      this.patchFormValue();
    } else {
      const points_of_contacts = this.pointOfContactForm.get('points_of_contacts') as FormArray
      for (let i=0; i<2; i++) {
        points_of_contacts.push(this.createPointOfContact())
      }
    }
    this.subscription.add(this.userService.checkSaveAndExit().subscribe(data => {
      if (data.isSaveAndExit && data.currentForm == 'point-of-contact') {
        this.userService.isSaveAndExit.next({ isSaveAndExit: false, currentForm: null });
        this.onClickContinue(1);
      }
    }));
    this.checkFormChanges();
  }

  ngOnDestroy() {
    if(!this.continueBtnClicked) {
      if (!this.applicationService.getSaveAndExit()) {
        if (this.currentApplication.response.point_of_contact.length > 0) {
          if (this.checkArrObjAreEqual(this.pointOfContactForm.value.points_of_contacts, this.currentApplication.response.point_of_contact)) {
            this.onClickContinue(3);
          }
        }
      }
    } else {
      this.applicationService.setTabChange(false);
    }
    this.pointOfContactFormInitialize();
  }

  pointOfContactFormInitialize() {
    this.pointOfContactForm = this.fb.group({
      points_of_contacts : this.fb.array([this.createPointOfContact()])
    });
  }

  createPointOfContact(): FormGroup {
    return new FormGroup({
      'point_of_contact' : new FormControl('', Validators.required),
      'title': new FormControl('', Validators.required),
      'primary_phone': new FormControl('', [Validators.required, Validators.minLength(14), Validators.maxLength(14)]),
      'alternate_phone': new FormControl('', [Validators.minLength(14), Validators.maxLength(14)])
    })
  }

  addPointOfContact() {
    const points_of_contacts = this.pointOfContactForm.get('points_of_contacts') as FormArray
    points_of_contacts.push(this.createPointOfContact());
  }

  deletePointOfContact(i: number) {
    const points_of_contacts= this.pointOfContactForm.get('points_of_contacts') as FormArray
    if (points_of_contacts.length > 1) {
      points_of_contacts.removeAt(i)
    } else {
      points_of_contacts.reset()
    }
  }

  patchFormValue() {
    const points_of_contacts = this.pointOfContactForm.get('points_of_contacts') as FormArray
    points_of_contacts.controls[0].patchValue({'point_of_contact' : this.currentApplication.response.point_of_contact[0]['point_of_contact']})
    points_of_contacts.controls[0].patchValue({'title' : this.currentApplication.response.point_of_contact[0]['title']})
    points_of_contacts.controls[0].patchValue({'primary_phone' : this.currentApplication.response.point_of_contact[0]['primary_phone']})
    points_of_contacts.controls[0].patchValue({'alternate_phone' : this.currentApplication.response.point_of_contact[0]['alternate_phone']})
    if (this.currentApplication.response.point_of_contact.length > 1) {
      for (let i=1; i<this.currentApplication.response.point_of_contact.length; i++) {
        points_of_contacts.push(this.createPointOfContact());
        points_of_contacts.controls[i].patchValue({'point_of_contact' : this.currentApplication.response.point_of_contact[i]['point_of_contact']})
        points_of_contacts.controls[i].patchValue({'title' : this.currentApplication.response.point_of_contact[i]['title']})
        points_of_contacts.controls[i].patchValue({'primary_phone' : this.currentApplication.response.point_of_contact[i]['primary_phone']})
        points_of_contacts.controls[i].patchValue({'alternate_phone' : this.currentApplication.response.point_of_contact[i]['alternate_phone']})
      }
    }
  }

  goToPrevious() {
    this.router.navigate(['user/application/premises']);
  }

  onClickContinue(isSaveAndExit) {
    const points_of_contacts = this.pointOfContactForm.get('points_of_contacts') as FormArray

    this.isduplicatePointOfContacts = this.hasDuplicatePointOfContact(points_of_contacts.controls);

    this.isSubmit = true;

    if (this.pointOfContactForm.invalid || this.isduplicatePointOfContacts) {
      return false;
    }
    const payload = {
      ...this.pointOfContactForm.value,
      'tab' : this.settingConfig.applicationTab[5].value, // 6
      'application_id': this.currentApplication.response.id,
    }
    this.subscription.add(
      this.applicationService.callApplicationAPI(payload).subscribe((data: any) => {
        this.isSubmit = false;
        if (isSaveAndExit == 1) {
          this.router.navigate(['user/index']);
        } else if (isSaveAndExit == 2){
          this.userService.setCurrentApplication(data);
          this.applicationService.applicationData.next(data);
          this.router.navigate(['user/application/review']);
        }  else if (isSaveAndExit == 3){
          this.userService.setCurrentApplication(data);
          this.applicationService.applicationData.next(data);
        }
        this.subscription.unsubscribe();
      })
    );
  }

  hasDuplicatePointOfContact(arrObj) {
    var groups = arrObj.reduce((acc, cur) => {
      acc[cur['controls']['point_of_contact']['value']] = (acc[cur['controls']['point_of_contact']['value']] || 0) + 1;
      return acc;
    }, {});
    return Object.values(groups).some(num => num > 1);
  }

  checkArrObjAreEqual(arrObj1, arrObj2) {
    for(let k = 0; k < arrObj1.length; k++) {
      if (arrObj1.length != arrObj2.length) {
        return true;
      }else if (arrObj1[k].point_of_contact != arrObj2[k].point_of_contact || arrObj1[k].title != arrObj2[k].title || arrObj1[k].primary_phone != arrObj2[k].primary_phone || arrObj1[k].alternate_phone != arrObj2[k].alternate_phone) {
        return true;
      }
    }
    return false;
  }

  checkFormChanges() {
    this.subscription.add(
      this.pointOfContactForm.valueChanges.subscribe((data)=> {
        if(this.pointOfContactForm.valid) {
          this.applicationService.setTabChange(false);
        } else {
          this.applicationService.setTabChange(true);
        }
      })
    );
  }



}
