import { ApplicationPointOfContactComponent } from './application/application-point-of-contact/application-point-of-contact.component';
import { ApplicationWhereComponent } from './application/application-where/application-where.component';
import { ApplicationWhatComponent } from './application/application-what/application-what.component';
import { ApplicationNavComponent } from './application/application-nav/application-nav.component';
import { ApplicationComponent } from './application/application.component';
import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserAuthGuard } from 'src/app/core/guards/user-auth.guard';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { ApplicationIndexComponent } from './application-index/application-index.component';
import { ApplicationAlarmHolderComponent } from './application/application-alarm-holder/application-alarm-holder.component';
import { ApplicationInstallerComponent } from './application/application-installer/application-installer.component';
import { ApplicationPremisesComponent } from './application/application-premises/application-premises.component';
import { ApplicationReviewComponent } from './application/application-review/application-review.component';
import { AchComponent } from './ach/ach.component';
import { AchIndexComponent } from './ach/ach-index/ach-index.component';
import { RegisterAccountComponent } from './ach/register-account/register-account.component';
import { PaymentComponent } from './payment/payment/payment.component';
import { PaymentSuccessfulComponent } from './payment/payment-successful/payment-successful.component';


const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    children: [
      // {
      //   path: '',
      //   component: HomeComponent
      // },
      {
        path: 'index',
        component: ApplicationIndexComponent
      },
      {
        path: 'application',
        component: ApplicationComponent,
        canActivateChild: [UserAuthGuard],
        children: [
          {
            path: 'what',
            component: ApplicationWhatComponent
          },
          {
            path: 'where',
            component: ApplicationWhereComponent
          },
          {
            path: 'alarm-holder',
            component: ApplicationAlarmHolderComponent
          },
          {
            path: 'installer',
            component: ApplicationInstallerComponent
          },
          {
            path: 'premises',
            component: ApplicationPremisesComponent
          },
          {
            path: 'point-of-contact',
            component: ApplicationPointOfContactComponent
          },
          {
            path: 'review',
            component: ApplicationReviewComponent
          },
        ]
      },
      {
        path: 'ach',
        component: AchComponent,
        children: [
          {
            path: 'index',
            component: AchIndexComponent
          },
          {
            path: 'register-account',
            component: RegisterAccountComponent
          }
        ]
      },
      {
        path: 'update-profile',
        component: UpdateProfileComponent
      },
      {
        path: 'application/payment',
        component: PaymentComponent
      },
      {
        path: 'application/payment-success',
        component: PaymentSuccessfulComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersRoutingModule {
  static component = [
    HomeComponent,
    UpdateProfileComponent,
    ApplicationIndexComponent,
    ApplicationComponent,
    ApplicationNavComponent,
    ApplicationWhatComponent,
    ApplicationWhereComponent,
    ApplicationAlarmHolderComponent,
    ApplicationInstallerComponent,
    ApplicationPremisesComponent,
    ApplicationPointOfContactComponent,
    ApplicationReviewComponent,
    AchComponent,
    AchIndexComponent,
    RegisterAccountComponent,
    PaymentComponent,
    PaymentSuccessfulComponent
  ]
}
