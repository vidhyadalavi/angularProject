import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { appToaster } from 'src/app/configs';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { UsersService } from 'src/app/core/services';
import { Location } from '@angular/common';

const credentialsKey = 'currentUser';
@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit, OnDestroy {

  updateProfileForm: FormGroup;
  isSubmitted = false;
  private subscription: Subscription = new Subscription();

  constructor(private authservice: AuthenticationService, private userService: UsersService, private toastService:ToastrService, private router:Router, private fb: FormBuilder, private location: Location) { }

  ngOnInit() {
    this.updateProfileFormInitialize();
    this.prefillAvailableProfileData();
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  updateProfileFormInitialize() {
    this.updateProfileForm = this.fb.group({
      firstName: ['',Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['',[Validators.required, Validators.maxLength(14), Validators.minLength(14)]],
      address:['']
    });
  }

  get profileControl() { return this.updateProfileForm.controls }

  prefillAvailableProfileData() {
    const localStorageData = this.authservice.getUser();
    if (localStorageData) {
      this.updateProfileForm.controls.firstName.setValue(localStorageData.first_name);
      this.updateProfileForm.controls.lastName.setValue(localStorageData.last_name);
      this.updateProfileForm.controls.email.setValue(localStorageData.email);
      this.updateProfileForm.controls.mobile.setValue(localStorageData.mobile_number ? localStorageData.mobile_number : '');
      this.updateProfileForm.controls.address.setValue(localStorageData.address);
    }
  }

  updateProfile() {

    this.isSubmitted = true
    if (this.updateProfileForm.invalid) {
      return false;
    }

    const payload = {
      first_name:this.updateProfileForm.value.firstName,
      last_name:this.updateProfileForm.value.lastName,
      email:this.updateProfileForm.value.email,
      mobile_number:this.updateProfileForm.value.mobile,
      address:this.updateProfileForm.value.address,
    }

    this.subscription.add(
      this.userService.updateUserProfile(payload).subscribe((data: any) => {
        const storage = localStorage;
        this.userService.userDetails.next(data.response);
        storage.setItem(credentialsKey, JSON.stringify(data.response));
        this.toastService.success(appToaster.profileUpdateSuccess);
        this.router.navigate(['user/index']);
      })
    );
  }

  onClickBackBtn() {
   this.location.back();
  }

}
