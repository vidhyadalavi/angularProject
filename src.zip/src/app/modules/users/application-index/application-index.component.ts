import { ToastrService } from 'ngx-toastr';
import { ApplicationService } from 'src/app/core/http/users/application.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { settingConfig } from 'src/app/configs';
import { UsersService } from 'src/app/core/services';
import { Subscription } from 'rxjs';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { browserRefresh } from 'src/app/app.component';
import { Location } from '@angular/common';
import { HttpParams } from '@angular/common/http';
import { appToaster } from 'src/app/configs';

@Component({
  selector: 'app-application-index',
  templateUrl: './application-index.component.html',
  styleUrls: ['./application-index.component.css']
})
export class ApplicationIndexComponent implements OnInit, OnDestroy {

  public settingsConfig = settingConfig;
  public pagination = {
    page: 1,
    limit: 10,
    totalDocuments: 0,
    search_string: ''
  };
  public applicationList = [];
  public cityList = [];
  public selectedCity = '';

  public browserRefresh = false;

  private subscription: Subscription = new Subscription();

  @ViewChild('cityModal', { static: false }) cityModal: ElementRef;

  constructor(private router: Router,   private userService: UsersService, private applicationService: ApplicationService, private toasterService: ToastrService, private route: ActivatedRoute, private authenticationService: AuthenticationService, private location: Location) { }

  ngOnInit() {
    this.editApplication('');
    this.userService.removeSelectedCity();
    this.userService.removeApplication();
    this.browserRefresh = browserRefresh;
    this.subscription.add(this.route.queryParams.subscribe((data: any) => {
      if (data && data.csrfToken) {
        this.subscription.add(this.applicationService.verifyCSRFToken({ token: data.csrfToken }).subscribe((data: any) => {
          this.authenticationService.loginDetailsBs.next(data.response);
          this.authenticationService.loggedOutBs.next(false);
          this.getCityList();
          this.getApplicationList(this.pagination);
          this.applicationService.setSaveAndExit(false);
          const [path, query] = this.location.path().split('?');
          const params = new HttpParams({ fromString: query });
          const theValueIWant = params.get('theParamIWant');
          this.location.replaceState(path, params.delete('csrfToken').toString());
        }));
      } else {
        this.getCityList();
        this.getApplicationList(this.pagination);
        this.applicationService.setSaveAndExit(false);
      }
    }));
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getCityList() {
    this.subscription.add(this.userService.getCityList().subscribe(data => {
      this.cityList = data;
    }));
  }

  selectCity(id) {
    this.userService.setSelectedCity(id);
    this.selectedCity = id;
  }

  hideModal() {
    this.cityModal.nativeElement.click();
  }

  onClickSubmit() {
    if (this.selectedCity) {
      this.hideModal();
      this.router.navigate(['user/application/what']);
    }
  }

  getApplicationList(pagination) {
    this.subscription.add(this.userService.getApplicationList(pagination).subscribe(data => {
      this.applicationList = data.response.applications.map((arrayElement) => Object.assign({}, arrayElement));
    
      this.applicationList.forEach((obj) => {
     
        obj.receipt_url = '';

        if (obj.application_payment_data.length > 0) {
          obj.application_payment_data.sort(function (a, b) {
            var c: any = new Date(a.createdAt);
            var d: any = new Date(b.createdAt);
            return c - d;
          });
          obj.application_payment_data.forEach(paymentData => {
            if (paymentData.status == null) {
              obj['payment_status_added'] = null;
            }
            if (obj.status == 1 && (paymentData.fee_type == 0 && paymentData.status == 3)) {
              obj.status = 4;
            } else if (obj.status == 1 && (paymentData.fee_type == 0 && paymentData.status == 4)) {
              obj.status = 4;
              obj['submitted_date'] = paymentData.updatedAt;
            } else if (paymentData.fee_type == 0 && paymentData.status == 4) {
              obj['submitted_date'] = paymentData.updatedAt;
            }
            if (paymentData.fee_type == 0) {
              obj['initial_payment_success'] = paymentData.status;
            }
            if (paymentData.fee_type == 0 && (paymentData.status == null || paymentData.status == 0 || paymentData.status == 2)) {
              obj['fee_type'] = 0;
            } else if (paymentData.fee_type == 0 && (paymentData.status == 3 || paymentData.status == 4 || paymentData.status == 5 || paymentData.status == 1)) {
              obj['fee_type'] = 1;
              obj['submitted_date'] = obj['submitted_date'] ? obj['submitted_date'] : paymentData.updatedAt;
            }

            if (paymentData.receipt_url && !obj.receipt_url) {
              obj.receipt_url = paymentData.receipt_url;
            }
          });
        } else {
          obj['initial_payment_success'] = obj['payment_status'];
        }
        if (obj.type_of_permit == 1) {
          if (obj.application_installer_details.length > 0) {
            obj.application_installer_details.forEach(installerObj => {
              if (installerObj.installer_type == 1 && installerObj.installation_date != null) {
                obj['installerComplete'] = true;
              } else if (installerObj.installer_type == 1 && installerObj.installation_date == null) {
                obj['installerComplete'] = false;
              }
            });
          }
        } else if (obj.type_of_permit == 2) {
          if (obj.application_installer_details.length > 0) {
            obj.application_installer_details.forEach(installerObj => {
              if (installerObj.installer_type == 2 && installerObj.installation_date != null) {
                obj['installerComplete'] = true;
              } else if (installerObj.installer_type == 2 && installerObj.installation_date == null) {
                obj['installerComplete'] = false;
              }
            });
          }
        } else if (obj.type_of_permit == 3) {
          if (obj.application_installer_details.length == 2 && obj.application_installer_details[0].installation_date != null && obj.application_installer_details[1].installation_date != null) {
            obj['installerComplete'] = true;
          } else {
            obj['installerComplete'] = false;
          }
        }
      });
      this.pagination.page = data.response.pagination.page;
      console.log("paginate ==>",  this.pagination.page)
      this.pagination.limit = data.response.pagination.limit;
      this.pagination.totalDocuments = data.response.pagination.totalDocuments;
      // this.editApplication('');
    }));
  }

  paginate(page) {
    this.applicationList = [];
    this.pagination['page'] = page;
    this.getApplicationList(this.pagination);
  }

  searchApplication(event) {
    if (event.target.value.length > 2 || event.target.value.length == 0) {
      this.pagination.search_string = event.target.value;
      this.getApplicationList(this.pagination);
    }
  }

  editApplication(application) {

    this.subscription.add(this.userService.getApplicationById({ application_id: application.id }).subscribe((data: any) => {
      this.userService.setCurrentApplication({ response: data, isEdit: true });
      if (data.point_of_contact.length > 0) {
        this.router.navigate(['user/application/what']);
      } else if (data.application_premises_details) {
        this.router.navigate(['user/application/point-of-contact']);
      } else if (data.application_installer_details.length > 0) {
        this.router.navigate(['user/application/premises']);
      } else if (data.application_alarm_holder_details) {
        this.router.navigate(['user/application/installer']);
      } else if (data.location_type) {
        this.router.navigate(['user/application/alarm-holder']);
      } else if (data.type_of_what) {
        this.router.navigate(['user/application/where']);
      }
    }));
  }
  renew_id=[];
  reverse_id:number=0;
  RenewPermit(payload){
    this.subscription.add(this.userService.renewPermit({ 'application_id': payload.id}).subscribe((data: any) => {
      if (data.status === 'success') {
              this.toasterService.success(appToaster.renewPermit, data.message);
              // this.getApplicationList(this.pagination);
              this.subscription.add(this.userService.getApplicationById({ application_id: data.response.id}).subscribe((data: any) => {
                console.log(data)
              this.userService.setCurrentApplication({ response: data, isEdit: true });  
              this.router.navigate(['user/application/alarm-holder']);
              }));
      } 
    }));
  }

  navigateToPaymentPage(applicationId, feeType, installerComplete) {
    if (installerComplete == true) {
      this.router.navigate(['user/application/payment'], { queryParams: { applicationId, feeType } });
    } else {
      this.toasterService.error('Installer details not complete');
    }
  }

  downloadPermit(id) {
    this.applicationService.downloadPermit(id, 2, 2);
  }

  checkAllPaymentNotCompleted(paymentList, status = null) {
    const found = paymentList.filter(el => el['status'] == status || el['status'] == 0)
    if (paymentList.length > 0 && found.length == 0) {
      return true;
    } else {
      return false;
    }
  }

  downloadReceipt(receiptUrl) {
    window.open(receiptUrl, '_blank');
  }

}
