import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AchAccountService } from 'src/app/core/http/users/ach-account.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-ach-index',
  templateUrl: './ach-index.component.html',
  styleUrls: ['./ach-index.component.css']
})
export class AchIndexComponent implements OnInit, OnDestroy {

  @ViewChild('verifyBankAccountModal', {static: false}) verifyBankAccountModal:ElementRef;
  @ViewChild('deleteBankAccountModal', {static: false}) deleteBankAccountModal:ElementRef;

  public verifyAmountForm: FormGroup;
  public isVerifyAmount = false;
  public accountId: string;
  public isHide = false;
  public achAccountId: number;
  public achAccounts = [];
  public config = {
    itemsPerPage: 10,
    currentPage: 1
  };

  private subscription: Subscription = new Subscription();

  constructor(private router: Router, private achAccountService: AchAccountService, private fb: FormBuilder, private toasterService: ToastrService) { }

  ngOnInit() {
    this.getAllAchAccount();
    this.initializeVerifyAmountForm();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  navigateToACHRegisterAccount() {
    this.router.navigate(['user/ach/register-account']);
  }

  navigateToApplicationIndex() {
    this.router.navigate(['user/index']);
  }

  initializeVerifyAmountForm() {
    this.verifyAmountForm = this.fb.group({
      amountOne: ['', Validators.required],
      amountTwo: ['', Validators.required],
    });
  }

  get verifyAmountFormControls() { return this.verifyAmountForm.controls; }

  getACHAccountId(accountId) {
    this.achAccountId = accountId
  }

  verifyACHAccount() {
    this.isVerifyAmount = true
    if (this.verifyAmountForm.invalid) {
      return false
    }
    const payload = {
      ...this.verifyAmountForm.value,
      accountId : this.accountId
    }
    this.isHide = true
    this.subscription.add(this.achAccountService.verifyACHAccount(payload).subscribe((data: any) => {
      this.isVerifyAmount = false;
      this.toasterService.success('ACH account verified');
      this.verifyBankAccountModal.nativeElement.click();
      this.getAllAchAccount();
      this.verifyAmountForm.controls.amountOne.reset('');
      this.verifyAmountForm.controls.amountTwo.reset('');
    }, (error: any) => {
        this.isVerifyAmount = false;
        this.verifyBankAccountModal.nativeElement.click();
        this.initializeVerifyAmountForm();
        this.getAllAchAccount();
        this.verifyAmountForm.controls.amountOne.reset('');
        this.verifyAmountForm.controls.amountTwo.reset('');
    }));
  }

  deleteACHAccount() {
    const payload = {
      account_id: this.achAccountId
    }
    this.subscription.add(this.achAccountService.deleteACHAccount(payload).subscribe((data: any) => {
      this.toasterService.success('ACH account deleted');
      this.deleteBankAccountModal.nativeElement.click();
      this.getAllAchAccount();
    }, (error: any) => {
      this.deleteBankAccountModal.nativeElement.click();
    }));
  }

  private getAllAchAccount(): void {
    this.subscription.add(this.achAccountService.getACHAccountListIndex().subscribe((data: any) => {
      this.achAccounts = data.response;
      // this.pagination.total = data.total;
      // this.offset = data.offset;
      // this.pagination.pages = Array(data.page).fill(0).map((x, i) => i + 1);
      // this.currentPagination = Number(data.page);
      this.config['totalItems'] = this.achAccounts.length;
    }));
  }

  findAccountID(accountId: string) {
    this.accountId = accountId;
    this.isVerifyAmount = false;
    this.verifyAmountForm.controls.amountOne.reset('');
    this.verifyAmountForm.controls.amountTwo.reset('');
  }

  pageChanged(event){
    this.config.currentPage = event;
  }

}
