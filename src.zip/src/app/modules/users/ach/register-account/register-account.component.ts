import { appToaster, settingConfig } from 'src/app/configs';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AchAccountService } from 'src/app/core/http/users/ach-account.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-register-account',
  templateUrl: './register-account.component.html',
  styleUrls: ['./register-account.component.css']
})
export class RegisterAccountComponent implements OnInit, OnDestroy {

  public registerAccountForm: FormGroup;
  public isSubmitted = false;
  public settings = settingConfig;
  public isDisabled = false;
  public token: string;
  private subscription: Subscription = new Subscription();

  constructor( private formBuilder: FormBuilder, private achAccountService: AchAccountService, private toasterService: ToastrService, private router: Router) { }

  ngOnInit() {
    this.registerAccountFormValidation();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  registerAccountFormValidation() {
    this.registerAccountForm = this.formBuilder.group({
      routingNumber: ['',Validators.required],
      accountNumber: ['',Validators.required],
      confirmAccountNumber: ['',Validators.required],
      fullName: ['',Validators.required],
      isSelect: ['',Validators.required]
    });
  }

  get registerAccountFormControls() { return this.registerAccountForm.controls; }

  genrateBankAccount() {
    this.isSubmitted = true
    if (this.registerAccountForm.invalid || (!this.registerAccountForm.value.isSelect)) {
      return false
    }
    this.isDisabled = true,
      (<any>window).Stripe.bankAccount.createToken({
        country: this.settings.ach.country,
        currency: this.settings.ach.currency,
        account_holder_name: this.registerAccountForm.value.fullName,
        account_holder_type: this.settings.ach.account_holder_type,
        routing_number: this.registerAccountForm.value.routingNumber,
        account_number: this.registerAccountForm.value.accountNumber,

      }, (status: number, response: any) => {
        if (status === 200) {
          this.token = `${response.id}`;
          if (this.token) {
            this.registerAccount()
            this.isDisabled = true
          }
        } else {
          this.toasterService.error(appToaster.errorHead, response.error.message);
          this.isDisabled = false;
        }
      });
  }

  registerAccount() {
    const payload ={
      token:this.token
    }
    this.subscription.add(this.achAccountService.addACHAccount(payload).subscribe((response) => {
        this.toasterService.success(appToaster.successHead, response.message);
        this.router.navigate(['user/ach/index']);
    }));
  }

  navigateToACHIndex(){
    this.router.navigate(['user/ach/index']);
  }

  navigateToApplicationIndex() {
    this.router.navigate(['user/index']);
  }

  accountMatchValidator(value: string) {
    if (value == 'confirmAccount' && (this.registerAccountForm.controls.accountNumber.value === this.registerAccountForm.controls.confirmAccountNumber.value)) {
       this.registerAccountForm.get('confirmAccountNumber').setErrors(null);
    }  else if(value == 'confirmAccount' && (this.registerAccountForm.controls.accountNumber.value != this.registerAccountForm.controls.confirmAccountNumber.value)){
      this.registerAccountForm.get('confirmAccountNumber').setErrors({'incorrect':true});
    }
    else if (value == 'account' && (this.registerAccountForm.controls.accountNumber.value === this.registerAccountForm.controls.confirmAccountNumber.value)) {
      this.registerAccountForm.get('confirmAccountNumber').setErrors(null);
    } else if (value == 'account' && (this.registerAccountForm.controls.accountNumber.value != this.registerAccountForm.controls.confirmAccountNumber.value)) {
      this.registerAccountForm.get('confirmAccountNumber').setErrors({ 'incorrect': true });
    }

  }
}
