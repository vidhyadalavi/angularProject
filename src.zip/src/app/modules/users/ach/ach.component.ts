import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ach',
  templateUrl: './ach.component.html',
  styleUrls: ['./ach.component.css']
})
export class AchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
