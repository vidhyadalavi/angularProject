import { Observable, Subscription, timer } from 'rxjs';
import { Router } from '@angular/router';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { LoaderService } from 'src/app/core/services';

@Component({
  selector: 'app-payment-successful',
  templateUrl: './payment-successful.component.html',
  styleUrls: ['./payment-successful.component.css']
})
export class PaymentSuccessfulComponent implements OnInit, OnDestroy {

  public timer: any;

  private subscription: Subscription = new Subscription();

  constructor(private router: Router, private loader: LoaderService) { }

  ngOnInit() {
    this.setTimer();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  navigateToApplicationIndexPage() {
    this.router.navigate(['user/index']);
  }

  setTimer() {
    this.loader.show();
    this.timer = timer(5000); // 5000 millisecond means 5 seconds
    this.subscription = this.timer.subscribe(() => {
        this.loader.hide();
    });
  }

}
