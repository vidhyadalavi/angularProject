import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { settingConfig } from 'src/app/configs';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { AchAccountService } from 'src/app/core/http/users/ach-account.service';
import { ApplicationService } from 'src/app/core/http/users/application.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit, OnDestroy {

  public achAccounts = []
  public type: any = 1;
  public isDisabled = false;

  public isChecked = true
  public creditCardForm: FormGroup;
  public achAccountForm: FormGroup;
  public submitted = false;
  public token: string;
  public isSubmit = false;
  public totalFee: number = 0
  public applicationFee = [];
  public achAccountId: number
  public applicationId: number
  public isHideAndShow = true;

  public fee = {
    processing: null,
    certificate: null,
    fire: null,
    id: null

  }
  public settings = settingConfig;

  public currentPagination: number = Number(1);
  public month: string;
  public year: string;
  public routingNumber: number;
  public accountNumber: number;
  public payments = {
    isPayment: null
  }
  public feeTypeForFee: number = 0;
  public applicationType: number;
  public transactionType: number = 1;
  public isShowFee = false;

  public feeType: number;
  public stripe_account: string; // acct_1HcReyKyghvyDdkJ

  public paymentData = {};
  public isACHAccount = false;

  public cardNumber;
  public cardExpiry;
  public cardCVC;

  public clientSecret: string;
  public isInvalidCard = false;
  public isInValidDate = false;
  public isInValidCVC = false;

  public stripeAccount;

  public applicationFeesConfig: any;
  public currentUser: any;

  private subscription: Subscription = new Subscription();
  private card;
  private stripe;

  constructor( private fb: FormBuilder,
    private achAccountService: AchAccountService,
    private applicationService: ApplicationService,
    private router: Router,
    private toasterService: ToastrService,
    private activatedRoute: ActivatedRoute,
    private authenticationService: AuthenticationService) {
     }

  ngOnInit() {
    this.initializeCreditCardForm();
    this.initializeACHAccountForm();
    this.activatedRoute.queryParams.subscribe(data => {
      this.applicationId = Number(data.applicationId);
      this.feeType = data.feeType ? Number(data.feeType) : 0;
      this.getAllAchAccount(this.applicationId);
      this.getApplicationFeesDetail();
      this.callStripe();
    });
    this.subscription.add(this.authenticationService.getUserInfo().subscribe(user => {
      this.currentUser = user ? user : null;
    })
    );
  }


  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  radioButton(value: string, transaction_type: number) {
    if (value == 'isTrue') {
      this.isChecked = true;
      this.transactionType = transaction_type

    } else if (value == 'isFalse') {
      this.isChecked = false;
      this.transactionType = transaction_type
    }
  }

  initializeCreditCardForm() {
    this.creditCardForm = this.fb.group({
      cardNumber: ['', []],
      zip: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5)]],
      cvv: ['', []],
      year: ['', []],
      isTermsAndConditions: ['', [Validators.required]],
    });
  }

  initializeACHAccountForm() {
    this.achAccountForm = this.fb.group({
      isTermsAndConditions: ['', Validators.required],
    })
  }

  ckeckBoxValidationCreditCard(event) {
    if (event.target.checked == true) {
      this.creditCardForm.controls.isTermsAndConditions.setErrors(null)
    } else if (event.target.checked == false) {
      this.creditCardForm.controls.isTermsAndConditions.setErrors({'required': true})
    }
  }

  checkBoxValidationACH(event) {
    if (event.target.checked == true) {
      this.achAccountForm.controls.isTermsAndConditions.setErrors(null)
    } else if (event.target.checked == false) {
      this.achAccountForm.controls.isTermsAndConditions.setErrors({'required': true})
    }
  }

  get getcreditCardFormControls() { return this.creditCardForm.controls }
  get getACHAccountFormControls() { return this.achAccountForm.controls }

  // genrateForBankAccount() {
  //   this.isSubmit = true
  //   if (this.achAccountForm.invalid) {
  //     return false
  //   }
  //   this.isDisabled = true,
  //     (<any>window).Stripe.bankAccount.createToken({
  //       country: this.settings.ach.country,
  //       currency: this.settings.ach.currency,
  //       // account_holder_name: 'Jenny Rosen',
  //       account_holder_type: this.settings.ach.account_holder_type,
  //       routing_number: this.routingNumber,
  //       account_number: this.accountNumber,
  //     }, (status: number, response: any) => {
  //       if (status === 200) {
  //         this.token = `${response.id}`;
  //         if (this.token) {
  //           this.isDisabled = true
  //         }
  //       } else {
  //         this.toasterService.error(appToaster.errorHead, response.error.message);
  //         this.isDisabled = false;
  //       }
  //     });
  // }

  private getAllAchAccount(id): void {
    this.subscription.add(this.achAccountService.getACHAccountList(id).subscribe((data) => {
      this.stripe_account = data.city_admin_stripe_account;
      // this.stripe_account = 'acct_1HcReyKyghvyDdkJ';
      this.achAccounts = data.response;
      if (this.achAccounts.length == 1) {
        this.accountNumber = data.response[0].accountNo;
        this.routingNumber = data.response[0].routingNo;
        this.achAccountId = data.response[0].id;
      }
      this.callStripe()
      if (data.applicationFee && data.application_fees_config) {
        data.applicationFee.map((fee, j) => {
          Object.keys(data.application_fees_config).map((config, i) => {
            if (fee.type == config) {
              this.totalFee += (fee.amount);

              this.applicationFee.push({ key: data.application_fees_config[config], amount: (fee.amount).toFixed(2), feeType: fee.feeType, createdAt: fee.createdAt, updatedAt: fee.updatedAt });
              if (this.applicationFee.length > 0) {
                this.feeType = this.applicationFee[0].feeType
              }
              if (data.applicationFee.length == j + 1) {
                this.applicationFee.push({ key: 'Total', amount: (this.totalFee).toFixed(2) })
              }
            }
          })
        })
      }
      if (this.applicationType == 2) {
        // this.getUnits()
      }
      // console.log(this.totalFee)
      this.achAccounts = this.achAccounts.filter(data => {
        if (data.isVerified == true) {
          data.isChecked = false
          return data;
        }
      })
      // console.log(this.achAccounts)
    }, (error: any) => {
      this.router.navigate(['user/index']);
    }));
  }

  savePayment() {
    if (this.achAccountForm.invalid) {
      this.isDisabled = false;
      this.isACHAccount = true
      return false
    }
    if (this.achAccountId) {
      this.isDisabled = true;
      this.paymentData = {
        //stripe_token: this.token,
        transaction_type: 2,
        feeType: this.feeType,
        // department_id: this.feeType,
        application_id: Number(this.applicationId),
        accountId: this.achAccountId
      }
      this.subscription.add(this.applicationService.savePayment(this.paymentData).subscribe((data: any) => {
        localStorage.setItem('payment', JSON.stringify({ isPayment: true }));
        this.router.navigate(['user/application/payment-success'], { queryParams: { application_id: this.applicationId, application_type: this.applicationType } });
      }, (error: any) => {
        this.isDisabled = false;
      }));
    } else {
      this.toasterService.error('Please select an ACH account');
    }
  }

  paymentByACHAccount(event, value) {
    this.achAccounts = this.achAccounts.map(data => {
      if (value.id == data.id) {
        data.isChecked = true
      }
      else {
        data.isChecked = false
      }
      return data;
    })
    if (event.target.checked) {
      this.accountNumber = value.accountNo;
      this.routingNumber = value.routingNo;
      this.achAccountId = value.id;
    }
  }

  cancelCreditCardForm() {
    this.creditCardForm.reset();
    this.isSubmit = false;
    this.router.navigate(['user/index']);
  }

  cancelButtonOnRouting() {
    this.achAccounts.map(data => {
      if (data.isChecked) {
        data.isChecked = false,
        this.accountNumber = null
        this.routingNumber = null
        this.achAccountId = null
      }
    })
    this.router.navigate(['user/index']);
  }

  onPress() {
    this.cardNumber.on('change', (event) => {
      if (event.complete) {
        this.isInvalidCard = false;
      } else {
        this.isInvalidCard = true;
      }
    });

  }

  createPaymentIntentAndSavePayment() {
    this.isSubmit = true;
    this.cardNumber.on('change', (event) => {
      if (event.complete) {
        this.isInvalidCard = false;
      } else {
        this.isInvalidCard = true;
      }
    });

    this.cardExpiry.on('change', (event) => {
      if (event.complete) {
        this.isInValidDate = false;
      } else {
        this.isInValidDate = true;
      }
    });

    this.cardCVC.on('change', (event) => {
      if (event.complete) {
        this.isInValidCVC = false;
      } else {
        this.isInValidCVC = true;
      }
    });

    var inputs = document.querySelectorAll('.cell.example.example2 .input');
    if (inputs[1].classList[2] == 'invalid' || inputs[1].classList[2] == 'empty' || inputs[1].classList[1] == 'empty') {
      this.isInvalidCard = true;
      if (inputs[2].classList[2] == 'invalid' || inputs[2].classList[2] == 'empty' || inputs[2].classList[1] == 'empty') {
        this.isInValidDate = true;
        if (inputs[3].classList[2] == 'invalid' || inputs[3].classList[2] == 'empty' || inputs[2].classList[1] == 'empty') {
          this.isInValidCVC = true;
        } else {
          this.isInValidCVC = false;
        }
      } else {
        this.isInValidDate = false;
      }
      return false;
    } else {
      this.isInvalidCard = false

    }

    if (inputs[2].classList[2] == 'invalid' || inputs[2].classList[2] == 'empty' || inputs[2].classList[1] == 'empty') {
      this.isInValidDate = true;
      if (inputs[3].classList[2] == 'invalid' || inputs[3].classList[2] == 'empty' || inputs[2].classList[1] == 'empty') {
        this.isInValidCVC = true;
      } else {
        this.isInValidCVC = false;
      }
      return false;
    } else {
      this.isInValidDate = false;

    }

    if (inputs[3].classList[2] == 'invalid' || inputs[3].classList[2] == 'empty' || inputs[2].classList[1] == 'empty') {
      this.isInValidCVC = true;
      return false
    } else {
      this.isInValidCVC = false;
    }
    if (this.creditCardForm.invalid) {
      this.isDisabled = false;
      return false;
    }
    this.isDisabled = true
    const intentData = {
      transaction_type: this.transactionType,
      feeType: this.feeType,
      // department_id: this.feeType,
      application_id: Number(this.applicationId),
    }
    this.subscription.add(this.applicationService.savePayment(intentData).subscribe(data => {
      // this.stripe_account = data.response.stripe_account;
      this.pay(data.response.client_secret);
    }, (error: any) => {
      this.isDisabled = false;
    }));
  }

  private async pay(secret: string) {
    const clientSecret = secret;
    this.stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: this.card,
        billing_details: {
          name: this.currentUser.first_name + ' ' + this.currentUser.last_name
        }
      }
    }).then((result) => {
      if (result.error) {
        this.isDisabled = false;
        this.toasterService.error(result.error.message);
      } else {
        if (result.paymentIntent.status === 'succeeded') {
          this.toasterService.success('Payment processed successfully');
          this.router.navigate(['user/application/payment-success'], { queryParams: { application_id: this.applicationId, application_type: this.applicationType } });
        }
      }
    })
  }

  callStripe() {
    (<any>window).initStripe(this.stripe_account);
    this.stripe = (<any>window).stripe;
    var elements = this.stripe.elements()

    var inputs = document.querySelectorAll('.cell.example.example2 .input');
    Array.prototype.forEach.call(inputs, function (input) {
      input.addEventListener('focus', function () {
        input.classList.add('focused');
      });
      input.addEventListener('blur', function () {
        input.classList.remove('focused');
      });
      input.addEventListener('keyup', function () {
        if (input.value && input.value.length === 0) {
          input.classList.add('empty');
        } else {
          input.classList.remove('empty');
        }
      });
    });

    var elementStyles = {
      base: {
        color: '#32325D',
        fontWeight: 500,
        fontFamily: 'Source Code Pro, Consolas, Menlo, monospace',
        fontSize: '16px',
        fontSmoothing: 'antialiased',

        '::placeholder': {
          color: '#CFD7DF',
        },
        ':-webkit-autofill': {
          color: '#e39f48',
        },
      },
      invalid: {
        color: '#E25950',

        '::placeholder': {
          color: '#FFCCA5',
        },
      },
    };

    var elementClasses = {
      focus: 'focused',
      empty: 'empty',
      invalid: 'invalid',
    };

    this.card = elements.create('cardNumber', {
      style: elementStyles,
      classes: elementClasses,
    });
    this.cardNumber = this.card
    this.card.mount('#example2-card-number');
    this.cardNumber.mount('#example2-card-number');


    this.card = elements.create('cardExpiry', {
      style: elementStyles,
      classes: elementClasses,
    });
    this.cardExpiry = this.card
    this.card.mount('#example2-card-expiry');
    this.cardExpiry.mount('#example2-card-expiry');


    this.card = elements.create('cardCvc', {
      style: elementStyles,
      classes: elementClasses,
    });
    this.cardCVC = this.card
    this.card.mount('#example2-card-cvc');
    this.cardCVC.mount('#example2-card-cvc');

  }

  getApplicationFeesDetail(transactionType = 1) {
    const params = {
      application_id: this.applicationId,
      feeType: this.feeType,
      transaction_type: transactionType
    };
    let totalFeeAmount = 0;
    this.applicationFee = [];
    this.subscription.add(this.applicationService.getApplicationFee(params).subscribe((data: any) => {
      this.applicationFee = data.response.applicationFee;
      this.applicationFeesConfig = data.response.application_fees_config;
      if (this.applicationFee) {
        Object.keys(this.applicationFeesConfig).forEach((feeConfigitem) => {
          this.applicationFee.forEach((feeItem) => {
            if(Number(feeConfigitem) == feeItem.type) {
              feeItem['feeDescription'] = this.applicationFeesConfig[feeConfigitem];
              totalFeeAmount += Number(this.applicationFee[this.applicationFee.findIndex(obj => obj.type === Number(feeConfigitem))].amount);
            }
          })
        })
        this.applicationFee.push({'feeDescription': 'Total', 'amount': Number(totalFeeAmount).toFixed(2) });
      }
    }, (error: any) => {
      this.router.navigate(['user/index']);
    }));
  }

  navigateToRegisterACHAccount() {
    this.router.navigate(['user/ach/register-account']);
  }

  navigateToIndexPage() {
    this.router.navigate(['user/index']);
  }

}
