import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { AdminIndexComponent } from './admin-index/admin-index.component';
import { CityAdminComponent } from './city-admin/city-admin.component';
import { AddCityAdminComponent } from './city-admin/add-city-admin/add-city-admin.component';
import { AddStaffComponent } from './staff/add-staff/add-staff.component';
import { StaffComponent } from './staff/staff.component';
import { ApplicationDetailComponent } from './application-detail/application-detail.component';
import { BasicDetailComponent } from './application-detail/basic-detail/basic-detail.component';
import { SubmissionReviewComponent } from './application-detail/submission-review/submission-review.component';
import { DecisionsComponent } from './application-detail/decisions/decisions.component';
import { FeeAndPaymentComponent } from './application-detail/fee-and-payment/fee-and-payment.component';
import { EmailAndNotesComponent } from './application-detail/email-and-notes/email-and-notes.component';
import { LayoutsModule } from 'src/app/core/layouts.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { AdminAuthGuard } from 'src/app/core/guards/admin-auth.guard';
import { SharedModule } from 'src/app/shared/modules/shared.module';

@NgModule({
  declarations: [
    AdminComponent,
    AdminIndexComponent,
    CityAdminComponent,
    AddCityAdminComponent,
    StaffComponent,
    AddStaffComponent,
    ApplicationDetailComponent,
    BasicDetailComponent,
    SubmissionReviewComponent,
    DecisionsComponent,
    FeeAndPaymentComponent,
    EmailAndNotesComponent,
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    LayoutsModule,
    NgxPaginationModule,
    SharedModule
  ],
  providers: [
    AdminAuthGuard
  ],
})
export class AdminModule { }
