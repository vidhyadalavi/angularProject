import { ToastrService } from 'ngx-toastr';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { settingConfig } from 'src/app/configs';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { AdminService } from 'src/app/core/services/admin/admin.service';
import * as moment from 'moment';

@Component({
  selector: 'app-admin-index',
  templateUrl: './admin-index.component.html',
  styleUrls: ['./admin-index.component.css']
})
export class AdminIndexComponent implements OnInit, OnDestroy {

  public selectedFile = null;
  public errorMessage = '';
  public hideModal = false;
  public currentUser = null;
  public pagination = {
    page: 1,
    limit: 10,
    totalDocuments: 0,
  };
  public searchString = '';
  public applicationList = [];
  public applicationType = 1;
  public settingsConfig = settingConfig;
  public searchFilter = {
    startDate: null,
    endDate: null,
    status: {
      draft: 0,
      complete: 0,
      incomplete: 0,
      accepted: 0,
      submitted: 0,
      issued: 0
    }
  }
  public maxDate = new Date();
  public minDate = moment(new Date()).add(-50, 'years').toDate();

  private subscription: Subscription = new Subscription();

  constructor(private adminService: AdminService, private authenticationService: AuthenticationService, private router: Router, private activatedRoute: ActivatedRoute, private toasterService: ToastrService) { }

  ngOnInit() {

    this.subscription.add(this.activatedRoute.queryParams.subscribe(data => {
      this.applicationType = data.type ? data.type : 1;
      this.getApplicationIndex(this.pagination);
    }));
    this.subscription.add(this.authenticationService.getUserInfo().subscribe(data => {
      this.currentUser = data;
    }));

  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  selectFile(event) {
    this.selectedFile = event.target.files[0];
    this.errorMessage = '';
  }

  clearSelectedFile() {
    this.selectedFile = null;
    this.errorMessage = '';
  }

  uploadAddress() {
    this.selectedFile = null;
  }

  uploadAddressFile() {
    if (this.errorMessage != '' || !this.selectedFile) {
      return false;
    }
    this.hideModal = true;
    let formData = new FormData();
    formData.append('city_address', this.selectedFile);
    // formData.append('id', this.currentUser.id);
    // let payload = {
    //   id: this.currentUser.id,
    //   city_address: this.selectedFile
    // }
    this.subscription.add(this.adminService.saveAddressCSVFile(formData).subscribe((data: any) => {
      this.toasterService.success("Address uploaded successfully");
      this.selectedFile = null;
      this.hideModal = false;
    }, (error: any) => {
      this.selectedFile = null;
      this.hideModal = false;
    }));
  }

  getApplicationIndex(pagination) {
    if (this.searchFilter.startDate) {
      pagination.submission_from = this.searchFilter.startDate.toISOString()
    } else {
      // pagination.submission_from = null;
      delete pagination.submission_from;
    }
    if (this.searchFilter.endDate) {
      pagination.submission_to = this.searchFilter.endDate.toISOString()
    } else {
      // pagination.submission_to = null;
      delete pagination.submission_to;
    }

    if (this.searchFilter.status.draft == 1) {
      pagination.draft = 1
    } else {
      // pagination.draft = 0
      delete pagination.draft;
    }
    if (this.searchFilter.status.submitted == 1) {
      pagination.submitted = 1
    } else {
      // pagination.submitted = 0
      delete pagination.submitted;
    }
    if (this.searchFilter.status.incomplete == 1) {
      pagination.incomplete = 1
    } else {
      // pagination.incomplete = 0
      delete pagination.incomplete;
    }
    if (this.searchFilter.status.complete == 1) {
      pagination.complete = 1
    } else {
      // pagination.complete = 0
      delete pagination.complete;
    }
    if (this.searchFilter.status.accepted == 1) {
      pagination.accepted = 1
    } else {
      // pagination.accepted = 0
      delete pagination.accepted;
    }
    if (this.searchFilter.status.issued == 1) {
      pagination.issued = 1
    } else {
      // pagination.issued = 0
      delete pagination.issued;
    }
    this.subscription.add(this.adminService.getApplicationList({ ...pagination, applicationType: this.applicationType }).subscribe(data => {
      this.applicationList = data.response.map((arrayElement) => Object.assign({}, arrayElement));
      this.applicationList.forEach((obj) => {
        if (obj.application_payment_data && obj.application_payment_data.length > 0) {
          obj.application_payment_data.sort(function (a, b) {
            var c: any = new Date(a.createdAt);
            var d: any = new Date(b.createdAt);
            return c - d;
          });
          obj.application_payment_data.forEach((paymentData) => {
            if (paymentData.status == null) {
              obj['payment_status_added'] = null;
            }
            if (obj.status == 1 && (paymentData.fee_type == 0 && paymentData.status == 3)) {
              obj.status = 4;
            } else if (obj.status == 1 && (paymentData.fee_type == 0 && paymentData.status == 4)) {
              obj.status = 4;
              obj['submitted_date'] = paymentData.updatedAt;
            } else if (paymentData.fee_type == 0 && paymentData.status == 4) {
              obj['submitted_date'] = paymentData.updatedAt;
            }
            if (paymentData.fee_type == 0 && (paymentData.status == null || paymentData.status == 0)) {
              obj['fee_type'] = 0;
            } else if (paymentData.fee_type == 0 && (paymentData.status == 3)) {
              obj['fee_type'] = 1;
              obj['submitted_date'] = obj['submitted_date'] ? obj['submitted_date'] : paymentData.updatedAt;
            }
          });
        }
      });
      this.pagination.page = data.pagination.page;
      this.pagination.limit = data.pagination.limit;
      this.pagination.totalDocuments = data.pagination.totalDocuments;
    }));
  }

  paginate(page) {
    this.applicationList = [];
    this.pagination['page'] = page;
    this.getApplicationIndex(this.pagination);
  }

  searchApplication() {
    if (this.searchString.length > 2 || this.searchString.length == 0) {
      if (this.searchString) {
        this.pagination['search_string'] = this.searchString
      } else {
        delete this.pagination['search_string'];
      }
      // this.pagination['search_string'] = this.searchString ? this.searchString : '';
      this.pagination['page'] = 1;
      let pagination = { ...this.pagination, };
      this.getApplicationIndex(pagination);
    }
  }

  goToApplicationDetail(id) {
    // if (this.currentUser.role != 4) {
    this.router.navigate(['admin/application-detail'], { queryParams: { id } })
    // }
  }

  selectFilter(event, mainKey, key) {
    this.searchFilter[mainKey][key] = event.target.checked ? 1 : 0;
  }

  resetSearchFilter() {
    this.searchFilter = {
      startDate: null,
      endDate: null,
      status: {
        draft: 0,
        complete: 0,
        incomplete: 0,
        accepted: 0,
        submitted: 0,
        issued: 0
      }
    }
    this.pagination['page'] = 1;
    this.getApplicationIndex(this.pagination);

  }

  handleDateRange(event) {
    if (event) {
      this.searchFilter.startDate = new Date(event[0]),
        this.searchFilter.endDate = new Date(event[1])
    }
  }

}
