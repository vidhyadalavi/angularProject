import { Subscription } from 'rxjs';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/core/services/admin/admin.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-city-admin',
  templateUrl: './add-city-admin.component.html',
  styleUrls: ['./add-city-admin.component.css']
})
export class AddCityAdminComponent implements OnInit, OnDestroy {

  public cityAdminForm: FormGroup;
  public isSubmit = false;
  public isActive = true;
  public editAdmin = null;
  public selectedFile: any = null;
  public imageName:string ;
  public isAddress = true;

  private subscription: Subscription = new Subscription();

  @ViewChild('addressupl', { static: false }) addressupl: ElementRef;

  constructor(private fb: FormBuilder, private adminService: AdminService, private router: Router, private toasterService: ToastrService) { }

  ngOnInit() {
    this.initializeCityAdminForm();
    this.editAdmin = this.adminService.getCurrentStaff();
    if (this.editAdmin) {
      this.patchFormValue();
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  initializeCityAdminForm() {
    this.cityAdminForm = this.fb.group({
      first_name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
      last_name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
      email: ['', [Validators.required, Validators.email]],
      city: ['', [Validators.required]],
      stripe_id: ['', [Validators.required]],
      mayor_name: ['', [Validators.required]]
    });
  }

  patchFormValue() {
    this.cityAdminForm.patchValue({
      first_name: this.editAdmin.first_name,
      last_name: this.editAdmin.last_name,
      email: this.editAdmin.email,
      city: this.editAdmin.city,
      stripe_id: this.editAdmin.stripe_id,
      mayor_name: this.editAdmin.mayor_name
    });
    this.isActive = this.editAdmin.status === 1 || this.editAdmin.status === 2 ? true : false;
  }

  onClickSubmit() {
    const formData = new FormData();
    this.isSubmit = true;
    if (this.cityAdminForm.invalid) {
      return false;
    }
    if (this.editAdmin) {
      formData.append('first_name', this.cityAdminForm.value.first_name),
      formData.append('last_name', this.cityAdminForm.value.last_name),
      formData.append('email', this.cityAdminForm.value.email),
      formData.append('city', this.cityAdminForm.value.city),
      formData.append('stripe_id', this.cityAdminForm.value.stripe_id);
      formData.append('mayor_name', this.cityAdminForm.value.mayor_name);
      formData.append('cb_status', this.editAdmin.cb_status);
      formData.append('status', String(this.isActive ? 1 : 0));
      formData.append('cityAdminId', this.editAdmin.id)
      if (this.selectedFile) {
        formData.append('city_address', this.selectedFile);
      }
      this.subscription.add(this.adminService.updateCityAdmin(formData).subscribe((data: any) => {
        if (this.selectedFile && (JSON.stringify(this.cityAdminForm.value) == JSON.stringify({
          first_name: this.editAdmin.first_name,
          last_name: this.editAdmin.last_name,
          email: this.editAdmin.email,
          city: this.editAdmin.city,
          stripe_id: this.editAdmin.stripe_id,
          mayor_name: this.editAdmin.mayor_name
        }))) {
          this.toasterService.success("Address updated successfully");
          this.router.navigate(['admin/city-admin']);
        } else {
          this.toasterService.success("City Admin updated successfully");
          this.router.navigate(['admin/city-admin']);
        }
      }));
    } else {
        // const payload = {
        //   ...this.cityAdminForm.value,
        //   status: this.isActive ? 1 : 0,
        //   city_address: this.selectedFile
        // }
        formData.append('first_name', this.cityAdminForm.value.first_name),
        formData.append('last_name', this.cityAdminForm.value.last_name),
        formData.append('email', this.cityAdminForm.value.email),
        formData.append('city', this.cityAdminForm.value.city),
        formData.append('stripe_id', this.cityAdminForm.value.stripe_id);
        formData.append('mayor_name', this.cityAdminForm.value.mayor_name);
        formData.append('cb_status', String(this.isActive ? 1 : 0));
        formData.append('status', String(this.isActive ? 1 : 0));
        if (this.selectedFile) {
          formData.append('city_address', this.selectedFile);
        }
        this.subscription.add(this.adminService.addCityAdmin(formData).subscribe((data: any) => {
          this.router.navigate(['admin/city-admin']);
        }));
    }
  }

  navigateToCityAdmin() {
    this.router.navigate(['admin/city-admin']);
  }

  selectFile(event) {
    this.selectedFile = event.target.files[0];
    this.imageName = event.target.files[0].name;
    this.isAddress = false
  }

  clear() {
    this.isAddress = true;
    this.selectedFile = null;
    this.imageName = '';
  }

  addressUpload() {
    this.addressupl.nativeElement.click()
  }

}
