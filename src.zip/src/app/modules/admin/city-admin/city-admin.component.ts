import { Subscription } from 'rxjs';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/core/services/admin/admin.service';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-city-admin',
  templateUrl: './city-admin.component.html',
  styleUrls: ['./city-admin.component.css']
})
export class CityAdminComponent implements OnInit, OnDestroy {

  public cityAdminList = [];
  public pagination = {
    page: 1,
    limit: 10,
    totalDocuments: 0
  };
  public search_query = '';
  public showPassword = false;
  public cityAdminPasswordResetForm: FormGroup;
  public isSubmit = false;
  public selectedCityAdminEmail: String;

  @ViewChild('closeCityAdminModal', {static : false}) private closeCityAdminModal: ElementRef;

  private subscription: Subscription = new Subscription();

  constructor(private adminService: AdminService, private router: Router, private toasterService: ToastrService, private fb: FormBuilder) { }

  ngOnInit() {
    this.adminService.removeCurrentStaff();
    this.getCityAdmin(this.pagination);
    this.initializeCityAdminResetPasswordForm();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getCityAdmin(pagination) {
    this.subscription.add(this.adminService.getCityAdminList(pagination).subscribe(data => {
      this.cityAdminList = data.response;
      this.pagination['page'] = data.pagination.page;
      this.pagination['limit'] = data.pagination.limit;
      this.pagination['totalDocuments'] = data.pagination.totalDocuments;
    }));
  }

  paginate(page) {
    this.pagination['page'] = page;
    this.getCityAdmin(this.pagination);
  }

  editAdmin(item) {
    this.adminService.setCurrentStaff(item);
    this.router.navigate(['admin/add-city-admin']);
  }

  resendStaffLink(id) {
    this.subscription.add(this.adminService.resendStaffLink({ id }).subscribe((data: any) => {
    }));
  }

  goToIndex() {
    this.router.navigate(['admin/index'], { queryParams: { type: 'admin' }});
  }

  searchApplication() {
    this.pagination['search_query'] = this.search_query;
    this.pagination['page'] = 1;
    this.getCityAdmin(this.pagination);
  }

  navigateToAddNewCityPage() {
    this.router.navigate(['admin/add-city-admin']);
  }

  editCityAdmin(admin) {
    this.adminService.setCurrentStaff(admin);
    this.router.navigate(['admin/add-city-admin']);
  }

  showAndHidePassword(showPassword) {
    if (showPassword) {
      this.showPassword = false;
    } else if (!showPassword) {
      this.showPassword = true;
    }
  }

  resetPassword() {
    this.isSubmit = true;

    if (this.cityAdminPasswordResetForm.invalid) {
      return false;
    }
    const payload = {
        email: this.selectedCityAdminEmail,
        ...this.cityAdminPasswordResetForm.value
    };
    this.subscription.add(this.adminService.cityAdminStaffResetPassword(payload).subscribe((data: any) => {
        this.isSubmit = false;
        this.selectedCityAdminEmail = '';
        this.toasterService.success("Password reset successfull");
        this.closeCityAdminModal.nativeElement.click();
    }));
  }

  initializeCityAdminResetPasswordForm() {
    this.cityAdminPasswordResetForm = this.fb.group({
      password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(30)]],
      cnfPassword: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(30)]]
    });
  }

  setSelectedCityAdminEmail(cityAdminEmail) {
    this.selectedCityAdminEmail = cityAdminEmail;
    this.cityAdminPasswordResetForm.reset();
    this.initializeCityAdminResetPasswordForm();
    this.isSubmit = false;
    this.showPassword = false;
  }

  checkPasswordMatch() {
    let password = this.cityAdminPasswordResetForm.get('password').value;
    let cnfPassword = this.cityAdminPasswordResetForm.get('cnfPassword').value;
    if (password == cnfPassword) {
      this.cityAdminPasswordResetForm.get('cnfPassword').setErrors(null);
      this.cityAdminPasswordResetForm.get('cnfPassword').clearValidators();
      return true
    } else {
      this.cityAdminPasswordResetForm.get('cnfPassword').setErrors({ invalid: true });
      return false;
    }
  }

  get password() { return this.cityAdminPasswordResetForm.get('password') }
  get cnfPassword() { return this.cityAdminPasswordResetForm.get('cnfPassword') }

}
