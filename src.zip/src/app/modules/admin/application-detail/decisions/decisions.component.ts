import { ApplicationService } from './../../../../core/http/users/application.service';
import { ToastrService } from 'ngx-toastr';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment'
import { Subscription } from 'rxjs';
import { settingConfig } from 'src/app/configs';
import { AdminService } from 'src/app/core/services/admin/admin.service';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
@Component({
  selector: 'app-decisions',
  templateUrl: './decisions.component.html',
  styleUrls: ['./decisions.component.css']
})
export class DecisionsComponent implements OnInit, OnDestroy {

  public currentApplication = null;
  public settingConfig = settingConfig;
  public expiration_days = [
    {
      key: '7 Days',
      value: 1,
      days: 7
    },
    {
      key: '30 Days',
      value: 2,
      days: 30
    },
    {
      key: '60 Days',
      value: 3,
      days: 60
    },
    {
      key: '90 Days',
      value: 4,
      days: 90
    },
    {
      key: '6 Month',
      value: 5,
      month: 6
    },
    {
      key: '1 Year',
      value: 6,
      year: 1
    },
    {
      key: '2 Year',
      value: 7,
      year: 2
    }
  ];
  public permitStatus = [
    {key: 'Issue Permit', value: 5}
  ]
  public selectedDate = null;
  public minDate = moment(new Date()).toDate();
  public maxDate = moment(new Date()).add(3, 'years').toDate();
  public decisionForm: FormGroup;
  public isSubmit = false;
  public decisions = [];
  public currentUser: any;

  private subscription: Subscription = new Subscription();

  constructor( private adminService: AdminService, private fb: FormBuilder, private toasterService: ToastrService, private applicationService: ApplicationService, private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.subscription.add(this.authenticationService.getUserInfo().subscribe(user => {
      this.currentUser = user ? user : null;
    }));
    this.initializeDecisionForm();
    this.getCurrentApplication();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  initializeDecisionForm() {
    this.decisionForm = this.fb.group({
      decision: ['', [Validators.required]],
      expiration_days: [''],
      expiration_date: [{value: '', disabled: false}, [Validators.required]],
      description: ['']
    })
  }

  getCurrentApplication() {
    this.subscription.add(this.adminService.getCurrentApplication().subscribe(data => {
      this.currentApplication = data;
      if (this.currentApplication) {
        this.decisions = this.currentApplication.application_decision_data;
      }
    }));
  }

  handleDateRange(event) {
    this.selectedDate = moment(new Date(event)).format('MM-DD-YYYY');
  }

  onDayChange(event) {
      const data = event.target.value;
      let expiryDate = null;
      if (data >= 1 && data <= 4) {
        expiryDate = moment(new Date()).add(this.expiration_days[data - 1].days, 'days').toDate();
      }
      if (data == 5) {
        expiryDate = moment(new Date()).add(this.expiration_days[data - 1].month, 'months').toDate();
      }
      if (data > 5) {
        expiryDate = moment(new Date()).add(this.expiration_days[data - 1].year, 'years').toDate();
      }
      this.decisionForm.patchValue({
        expiration_date: expiryDate
      });
  }

  submitDecision() {
    this.isSubmit = true;
    if (this.decisionForm.invalid) {
      return false;
    }
    const payload = {
      ...this.decisionForm.value,
      application_id: this.currentApplication.id,
    }
    this.subscription.add(this.adminService.postDecision(payload).subscribe(data => {
      this.toasterService.success("Permit issued successfully");
      this.isSubmit = false;
      this.decisionForm.reset();
      this.initializeDecisionForm();
      this.decisions = data;
    }));
  }

  voidDecision(id) {
    const payload = {
      id,
      application_id: this.currentApplication.id
    }
    this.subscription.add(this.adminService.voidDecision(payload).subscribe(data => {
      this.toasterService.success("Void successfully");
      this.decisions = data;
    }));
  }

  downloadPermit(id) {
    this.applicationService.downloadPermit(id, 2, 2);
  }

  permitConditionsClick() {
    if (this.decisionForm.get('description').value == '') {
      this.decisionForm.get('description').setValue('None');
    }
  }

}
