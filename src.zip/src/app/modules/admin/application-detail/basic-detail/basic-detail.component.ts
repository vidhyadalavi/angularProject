import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { settingConfig } from './../../../../configs/settings.config';
import { Subscription } from 'rxjs';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { AdminService } from 'src/app/core/services/admin/admin.service';
import * as moment from 'moment';
@Component({
  selector: 'app-basic-detail',
  templateUrl: './basic-detail.component.html',
  styleUrls: ['./basic-detail.component.css']
})
export class BasicDetailComponent implements OnInit, OnDestroy {

  public currentApplication = null;
  public settingConfig = settingConfig;
  public whereForm: FormGroup;
  public alarmHolderForm: FormGroup;
  public burglarInstallerForm: FormGroup;
  public fireInstallerForm: FormGroup;
  public premisesForm: FormGroup;
  public pointOfContactForm: FormGroup;
  public isAlarmHoldeFormSubmit = false;
  public hideModal = false;
  public isInstallerFormSubmit = false;
  public isPremisesFormSubmit = false;
  public hazardousMaterialAddForm: FormGroup
  public hazardousMaterialsList: Array<object> = [];
  public isEdit = false;
  public editHazardousMaterial: Object;
  public addHazardousMaterialFormSubmit = false;
  public addHazardousMaterialId = '1HMA';
  public isPointOfContactFormSubmit = false;
  public isduplicatePointOfContacts: boolean;
  public selectedDate = null;

  public maxDate = moment(new Date()).add(50, 'years').toDate();
  public minDate = moment(new Date()).toDate();
  public burglarInstallerObj: any;
  public fireInstallerObj: any;

  public addressList = [];
  public showDropDown = false;
  public selectedAddressId = '';
  public address: any;
  public googleAddressShow = false;

  @ViewChild('addHazardousMaterial', { static: false }) addHazardousMaterial: ElementRef;

  private subscription: Subscription = new Subscription();

  constructor(private adminService: AdminService, private fb: FormBuilder) { }

  ngOnInit() {
    this.initializeAlarmHolderForm();
    this.initializeWhereForm();
    this.burglarInstallerFormInitialize();
    this.fireInstallerFormInitialize();
    this.premisesFormInitialize();
    this.hazardousMaterialAddFormInitialize();
    this.pointOfContactFormInitialize();
    this.getCurrentApplication();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.adminService.setCurrentApplication(null);
  }

  getCurrentApplication() {
    this.subscription.add(this.adminService.getCurrentApplication().subscribe(data => {
      this.currentApplication = data;
      if (this.currentApplication) {
        if (this.currentApplication['google_address']) {
          this.googleAddressShow = true;
          this.whereForm.get('address_location').clearValidators();
          this.whereForm.get('address_location').setErrors(null);
          this.whereForm.get('google_address').setValidators(Validators.required);
          this.whereForm.get('google_address').setErrors({required: true});
        } else {
          this.googleAddressShow = false;
          this.whereForm.get('google_address').clearValidators();
          this.whereForm.get('google_address').setErrors(null);
          this.whereForm.get('address_location').setValidators(Validators.required);
          this.whereForm.get('address_location').setErrors({required: true});
        }
        this.currentApplication.application_installer_details.forEach((installerObj) => {
          if (installerObj.installer_type == 1) {
            this.burglarInstallerObj = {
              installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
              installer_first_name: installerObj.installer_first_name,
              installer_phone: installerObj.installer_phone,
              servcing_company_name: installerObj.servcing_company_name,
              servcing_company_phone: installerObj.servcing_company_phone,
              servcing_company_address: installerObj.servcing_company_address,
              city: installerObj.city,
              state: installerObj.state,
              zip: installerObj.zip,
              alarm_response: installerObj.alarm_response
            }
          } else if (installerObj.installer_type == 2) {
            this.fireInstallerObj = {
              installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
              installer_first_name: installerObj.installer_first_name,
              installer_phone: installerObj.installer_phone,
              servcing_company_name: installerObj.servcing_company_name,
              servcing_company_phone: installerObj.servcing_company_phone,
              servcing_company_address: installerObj.servcing_company_address,
              city: installerObj.city,
              state: installerObj.state,
              zip: installerObj.zip,
              alarm_response: installerObj.alarm_response
            }
          }
        });
      }
    }));
  }

  initializeWhereForm() {
    this.whereForm = this.fb.group({
      address_location: [''],
      google_address: [''],
      also_know_as: ['']
    });
  }

  initializeAlarmHolderForm() {
    this.alarmHolderForm = this.fb.group({
      // role : ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      first_name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
      last_name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
      business: ['', []],
      phone: ['', [Validators.required, Validators.minLength(14), Validators.maxLength(14)]],
      address_alarm: ['', [Validators.required]],
      // city: ['', [Validators.required]],
      // state: ['', [Validators.required]],
      // zip: ['', [Validators.required]]
    });
  }

  patchAlarmHolderForm() {
    this.alarmHolderForm.patchValue({
      // role : this.currentApplication.application_alarm_holder_details.role,
      email: this.currentApplication.application_alarm_holder_details.email,
      first_name: this.currentApplication.application_alarm_holder_details.first_name,
      last_name: this.currentApplication.application_alarm_holder_details.last_name,
      business: this.currentApplication.application_alarm_holder_details.business,
      phone: this.currentApplication.application_alarm_holder_details.phone ? this.currentApplication.application_alarm_holder_details.phone : '',
      address_alarm: this.currentApplication.application_alarm_holder_details.address,
      // city: this.currentApplication.application_alarm_holder_details.city,
      // state: this.currentApplication.application_alarm_holder_details.state,
      // zip: this.currentApplication.application_alarm_holder_details.zip
    });
  }

  patchWhereForm() {
    this.whereForm.patchValue({
      address_location: (!this.googleAddressShow) ? this.currentApplication.address : '',
      google_address: this.currentApplication.google_address,
      also_know_as: this.currentApplication.also_know_as
    });
    this.selectedAddressId = this.currentApplication.address_id;
  }

  burglarInstallerFormInitialize() {
    this.burglarInstallerForm = this.fb.group({
      installation_date: ['', [Validators.required]],
      installer_first_name: ['', [Validators.required]],
      installer_phone: ['', [Validators.required]],
      servcing_company_name: ['', [Validators.required]],
      servcing_company_phone: ['', [Validators.required]],
      servcing_company_address: ['', [Validators.required]],
      city: ['', [Validators.required]],
      state: ['', [Validators.required]],
      zip: ['', [Validators.required]],
      alarm_response: ['', [Validators.required]]
    });
  }

  fireInstallerFormInitialize() {
    this.fireInstallerForm = this.fb.group({
      installation_date: ['', [Validators.required]],
      installer_first_name: ['', [Validators.required]],
      installer_phone: ['', [Validators.required, Validators.minLength(14), Validators.maxLength(14)]],
      servcing_company_name: ['', [Validators.required]],
      servcing_company_phone: ['', [Validators.required, Validators.minLength(14), Validators.maxLength(14)]],
      servcing_company_address: ['', [Validators.required]],
      city: ['', [Validators.required]],
      state: ['', [Validators.required]],
      zip: ['', [Validators.required]],
      alarm_response: ['', [Validators.required]]
    });
  }

  patchInstallerFormsValue() {
    if (this.currentApplication.type_of_permit == 3) {
      this.currentApplication.application_installer_details.forEach((installerObj) => {
        if (installerObj.installer_type == 1) {
          this.burglarInstallerForm.patchValue({
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          });
        } else if (installerObj.installer_type == 2) {
          this.fireInstallerForm.patchValue({
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          });
        }
      });

    } else if (this.currentApplication.type_of_permit == 1) {
      this.currentApplication.application_installer_details.forEach((installerObj) => {
        if (installerObj.installer_type == 1) {
          this.burglarInstallerForm.patchValue({
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          });
        }
      });
    } else if (this.currentApplication.type_of_permit == 2) {
      this.currentApplication.application_installer_details.forEach((installerObj) => {
        if (installerObj.installer_type == 2) {
          this.fireInstallerForm.patchValue({
            installation_date: moment(new Date(installerObj.installation_date)).format('MM-DD-YYYY'),
            installer_first_name: installerObj.installer_first_name,
            installer_phone: installerObj.installer_phone,
            servcing_company_name: installerObj.servcing_company_name,
            servcing_company_phone: installerObj.servcing_company_phone,
            servcing_company_address: installerObj.servcing_company_address,
            city: installerObj.city,
            state: installerObj.state,
            zip: installerObj.zip,
            alarm_response: installerObj.alarm_response
          });
        }
      });
    }
  }

  premisesFormInitialize() {
    this.premisesForm = this.fb.group({
      fire_suppression_system: ['', [Validators.required]],
      is_watchman_or_guard: ['', [Validators.required]],
      is_animals: ['', [Validators.required]],
      is_hazadous: ['', [Validators.required]],
    });
  }

  patchPremisesFormValue() {
    this.premisesForm.patchValue({
      fire_suppression_system: this.currentApplication.application_premises_details.fire_suppression_system,
      is_watchman_or_guard: this.currentApplication.application_premises_details.is_watchman_or_guard,
      is_animals: this.currentApplication.application_premises_details.is_animals,
      is_hazadous: this.currentApplication.application_premises_details.is_hazadous,
    });

    this.hazardousMaterialsList = this.currentApplication['hazardous_material_details'] ? this.currentApplication['hazardous_material_details'].map((arrayElement) => Object.assign({}, arrayElement)) : [];
  }

  onClickSaveAlarmHolder() {
    this.isAlarmHoldeFormSubmit = true;
    if (this.alarmHolderForm.invalid || this.whereForm.invalid) {
      return false;
    }
    this.hideModal = true;
    const payload = {
      ...this.alarmHolderForm.value,
      ...this.whereForm.value,
      'address_id': this.selectedAddressId ? this.selectedAddressId : null,
      'email': (this.alarmHolderForm.value.email).toLowerCase(),
      'tab' : this.settingConfig.applicationTab[2].value, // 3
      'application_id': this.currentApplication.id,
    }
    this.subscription.add(this.adminService.updateApplicationByAdmin(payload).subscribe((data: any) => {
      this.isAlarmHoldeFormSubmit = false;
      this.adminService.setCurrentApplication(data);
      this.hideModal = false;
    }));
  }

  onClickSaveInstaller() {
    this.isInstallerFormSubmit = true;
    if (this.currentApplication.type_of_permit == 1 && (this.burglarInstallerForm.invalid)) {
      return false;
    } else if (this.currentApplication.type_of_permit == 2 && (this.fireInstallerForm.invalid)) {
      return false;
    } else if (this.currentApplication.type_of_permit == 3 && ((this.burglarInstallerForm.invalid) || (this.fireInstallerForm.invalid))) {
      return false;
    }
    let payload;
    this.hideModal = true;
    if (this.currentApplication.type_of_permit == 1) {
      payload = {
        'burglar_installer': this.burglarInstallerForm.value,
        'fire_installer': {},
        'tab' : this.settingConfig.applicationTab[3].value, // 4
        'application_id': this.currentApplication.id,
      }
    } else if (this.currentApplication.type_of_permit == 2) {
      payload = {
        'burglar_installer': {},
        'fire_installer': this.fireInstallerForm.value,
        'tab' : this.settingConfig.applicationTab[3].value, // 4
        'application_id': this.currentApplication.id,
      }
    } else if (this.currentApplication.type_of_permit == 3) {
      payload = {
        'burglar_installer': this.burglarInstallerForm.value,
        'fire_installer': this.fireInstallerForm.value,
        'tab' : this.settingConfig.applicationTab[3].value, // 4
        'application_id': this.currentApplication.id,
      }
    }
    this.subscription.add(this.adminService.updateApplicationByAdmin(payload).subscribe((data: any) => {
      this.isInstallerFormSubmit = false;
      this.adminService.setCurrentApplication(data);
      this.hideModal = false;
    }));

  }

  editApplicationDetails(val) {
    if (val == 1) {
      if (this.currentApplication && this.currentApplication.application_alarm_holder_details) {
        this.patchAlarmHolderForm();
        this.patchWhereForm();
      }
    } else if (val == 2) {
      if (this.currentApplication && this.currentApplication.application_installer_details.length > 0) {
        this.patchInstallerFormsValue();
      }
    } else if (val == 3) {
      if (this.currentApplication && this.currentApplication.application_premises_details) {
        this.patchPremisesFormValue();
      }
    } else if (val == 4) {
      if (this.currentApplication && this.currentApplication.point_of_contact.length > 0) {
        this.pointOfContactFormInitialize();
        const points_of_contacts = this.pointOfContactForm.get('points_of_contacts') as FormArray;
        for (let i=1; i<this.currentApplication.point_of_contact.length; i++) {
          points_of_contacts.push(this.createPointOfContact());
        }
        this.patchPointOfContactFormValue();
      } else if (this.currentApplication && this.currentApplication.point_of_contact.length == 0) {
        const points_of_contacts = this.pointOfContactForm.get('points_of_contacts') as FormArray
        for (let i=0; i<2; i++) {
          points_of_contacts.push(this.createPointOfContact())
        }
      }
    }
  }

  pointOfContactFormInitialize() {
    this.pointOfContactForm = this.fb.group({
      points_of_contacts : this.fb.array([this.createPointOfContact()])
    });
  }

  createPointOfContact(): FormGroup {
    return new FormGroup({
      'point_of_contact' : new FormControl('', Validators.required),
      'title': new FormControl('', Validators.required),
      'primary_phone': new FormControl('', [Validators.required, Validators.minLength(14), Validators.maxLength(14)]),
      'alternate_phone': new FormControl('', [Validators.minLength(14), Validators.maxLength(14)])
    })
  }

  patchPointOfContactFormValue() {
    const points_of_contacts = this.pointOfContactForm.get('points_of_contacts') as FormArray;
    points_of_contacts.controls[0].patchValue({'point_of_contact' : this.currentApplication.point_of_contact[0]['point_of_contact']})
    points_of_contacts.controls[0].patchValue({'title' : this.currentApplication.point_of_contact[0]['title']})
    points_of_contacts.controls[0].patchValue({'primary_phone' : this.currentApplication.point_of_contact[0]['primary_phone']})
    points_of_contacts.controls[0].patchValue({'alternate_phone' : this.currentApplication.point_of_contact[0]['alternate_phone']})
    if (this.currentApplication.point_of_contact.length > 1) {
      for (let i=1; i<this.currentApplication.point_of_contact.length; i++) {
        // points_of_contacts.push(this.createPointOfContact());
        points_of_contacts.controls[i].patchValue({'point_of_contact' : this.currentApplication.point_of_contact[i]['point_of_contact']})
        points_of_contacts.controls[i].patchValue({'title' : this.currentApplication.point_of_contact[i]['title']})
        points_of_contacts.controls[i].patchValue({'primary_phone' : this.currentApplication.point_of_contact[i]['primary_phone']})
        points_of_contacts.controls[i].patchValue({'alternate_phone' : this.currentApplication.point_of_contact[i]['alternate_phone']})
      }
    }
  }

  hazardousMaterialAddFormInitialize() {
    this.hazardousMaterialAddForm = this.fb.group({
      hazardous_material_type: ['', [Validators.required]],
      hazardous_material_location: ['', [Validators.required]]
    })
  }

  hideHazardousMaterialModal() {
    this.addHazardousMaterial.nativeElement.click();
  }

  hazardousMaterialFormReset() {
    this.hazardousMaterialAddForm.reset();
    this.hazardousMaterialAddForm.get('hazardous_material_type').setValue('');
  }

  onClickActionEdit(material) {
    this.isEdit = true;
    this.editHazardousMaterial = material;
    this.hazardousMaterialAddForm.get('hazardous_material_type').setValue(material['hazardous_material_type']);
    this.hazardousMaterialAddForm.get('hazardous_material_location').setValue(material['hazardous_material_location']);
  }

  onClickActionDelete(material) {
    this.hazardousMaterialsList = this.hazardousMaterialsList.filter(function( obj ) {
      return obj['id'] !== material['id'];
    });
  }

  onClickSave() {
    this.addHazardousMaterialFormSubmit = true;
    if (this.hazardousMaterialAddForm.invalid) {
      return false;
    } else {
      this.hideHazardousMaterialModal();
      this.addHazardousMaterialFormSubmit = false;
      if (this.isEdit) {
        this.isEdit = false;
        this.hazardousMaterialsList.forEach((materialObj) => {
          if (this.editHazardousMaterial['id'] == materialObj['id']) {
            materialObj['hazardous_material_type'] = this.hazardousMaterialAddForm.value.hazardous_material_type;
            materialObj['hazardous_material_location'] = this.hazardousMaterialAddForm.value.hazardous_material_location;
          }
        })
      } else {
          this.hazardousMaterialsList.push({...this.hazardousMaterialAddForm.value, id : this.addHazardousMaterialId });
          this.addHazardousMaterialId = (Number(this.addHazardousMaterialId[0]) + 1) + 'HMA';
      }

      this.onClickSavePremises();
    }
  }

  onClickSavePremises() {
    this.isPremisesFormSubmit = true;
    if (this.premisesForm.invalid) {
      return false;
    }
    this.hideModal = true;
    const payload = {
      ...this.premisesForm.value,
      'hazardous_material' : this.hazardousMaterialsList,
      'tab' : this.settingConfig.applicationTab[4].value, // 5
      'application_id': this.currentApplication.id,
    }
    this.subscription.add(this.adminService.updateApplicationByAdmin(payload).subscribe((data: any) => {
      this.isPremisesFormSubmit = false;
      this.adminService.setCurrentApplication(data);
      this.hideModal = false;
    }));
  }

  addPointOfContact() {
    const points_of_contacts = this.pointOfContactForm.get('points_of_contacts') as FormArray
    points_of_contacts.push(this.createPointOfContact());
  }

  deletePointOfContact(i: number) {
    const points_of_contacts= this.pointOfContactForm.get('points_of_contacts') as FormArray
    if (points_of_contacts.length > 1) {
      points_of_contacts.removeAt(i)
    } else {
      points_of_contacts.reset()
    }
  }

  onClickSavePointOfContacts() {
    const points_of_contacts = this.pointOfContactForm.get('points_of_contacts') as FormArray

    this.isduplicatePointOfContacts = this.hasDuplicatePointOfContact(points_of_contacts.controls);

    this.isPointOfContactFormSubmit = true;
    if (this.pointOfContactForm.invalid || this.isduplicatePointOfContacts) {
      return false;
    }
    this.hideModal = true;
    const payload = {
      ...this.pointOfContactForm.value,
      'tab' : this.settingConfig.applicationTab[5].value, // 6
      'application_id': this.currentApplication.id,
    }
    this.subscription.add(this.adminService.updateApplicationByAdmin(payload).subscribe((data: any) => {
      this.isPointOfContactFormSubmit = false;
      this.adminService.setCurrentApplication(data);
      this.hideModal = false;
    }));
  }

  hasDuplicatePointOfContact(arrObj) {
    var groups = arrObj.reduce((acc, cur) => {
      acc[cur['controls']['point_of_contact']['value']] = (acc[cur['controls']['point_of_contact']['value']] || 0) + 1;
      return acc;
    }, {});
    return Object.values(groups).some(num => num > 1);
  }

  handleDateRange(event) {
    this.selectedDate = moment(new Date(event)).format('MM-DD-YYYY');
  }

  searchAddress() {
    let search_string = this.whereForm.get("address_location").value;
    this.subscription.add(this.adminService.searchAddress({ search_string, admin_id: this.currentApplication.city_id }).subscribe(data => {
      this.showDropDown = true;
      this.addressList = data;
    }));
  }

  selectAddress(item) {
    this.googleAddressShow = false;
    this.whereForm.get('google_address').setValue('');
    this.whereForm.get('google_address').clearValidators();
    this.whereForm.get('google_address').setErrors(null);
    this.whereForm.get('address_location').setValidators(Validators.required);
    this.whereForm.get('address_location').setErrors({required: true});
    this.showDropDown = false;
    this.selectedAddressId = item.id;
    this.address = item.property_location
    this.whereForm.patchValue({
      address_location: item.property_location + ' ' + '[SBL - ' + (item.sbl ? item.sbl : '') + "] " + '[QUAL - ' + ((item.qual == "NULL" || (!item.qual)) ? 'REGULAR' : item.qual) + ']'
    });
  }

  showSearchAddress() {
    if(this.whereForm.get('address_location').value) {
      this.whereForm.get('address_location').setValue('');
    }
    this.googleAddressShow = !this.googleAddressShow;
    if (this.googleAddressShow) {
      this.whereForm.get('address_location').clearValidators();
      this.whereForm.get('address_location').setErrors(null);
      this.whereForm.get('google_address').setValidators(Validators.required);
      this.whereForm.get('google_address').setErrors({required: true});
    } else {
      this.whereForm.get('google_address').clearValidators();
      this.whereForm.get('google_address').setErrors(null);
      this.whereForm.get('address_location').setValidators(Validators.required);
      this.whereForm.get('address_location').setErrors({required: true});
    }
  }

  googleAddress(event) {
    this.whereForm.get('google_address').setValue(event.formatted_address);
    this.whereForm.get('address_location').setValue('');
    this.selectedAddressId = null;
  }

  // checkIfAddressTyped(event) {
  //   let address = event.target.value;
  //   if (address != '') {
  //     this.whereForm.get('address').setValue('');
  //   }
  // }

}
