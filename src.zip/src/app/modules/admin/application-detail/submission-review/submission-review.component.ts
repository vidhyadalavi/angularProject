import { ToastrService } from 'ngx-toastr';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { settingConfig } from 'src/app/configs';
import { AdminService } from 'src/app/core/services/admin/admin.service';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';

@Component({
  selector: 'app-submission-review',
  templateUrl: './submission-review.component.html',
  styleUrls: ['./submission-review.component.css']
})
export class SubmissionReviewComponent implements OnInit, OnDestroy {

  public currentApplication = null;
  public submissionForm: FormGroup;
  public isSubmit = false;
  public settingConfig = settingConfig;
  public submissionReview = [];
  public currentUser: any;

  private subscription: Subscription = new Subscription();

  constructor(private adminService: AdminService, private fb: FormBuilder, private toasterService: ToastrService, private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.subscription.add(this.authenticationService.getUserInfo().subscribe(user => {
      this.currentUser = user ? user : null;
    }));
    this.initializeSubmissionForm();
    this.getCurrentApplication();
    // this.onDecisionChange();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  initializeSubmissionForm() {
    this.submissionForm = this.fb.group({
      decision: ['', [Validators.required]],
      description: [''],
      to: [''],
      cc: ['']
    });
  }

  getCurrentApplication() {
    this.subscription.add(this.adminService.getCurrentApplication().subscribe(data => {
      if (data) {
        this.currentApplication = data;
        this.submissionReview = this.currentApplication.submission_review;
        if (this.currentApplication && this.currentApplication.user_detail) {
          this.submissionForm.patchValue({
            to: this.currentApplication.user_detail.email
          })
        }
      }
    }));
  }

  onDecisionChange(data) {
    // this.subscription.add(this.submissionForm.valueChanges.subscribe(data => {
      if (data == 2) {
        this.submissionForm.get('description').setValidators([Validators.required]);
        this.submissionForm.get('description').setErrors({'required': true});
        this.submissionForm.get('to').setValidators([Validators.required, Validators.email]);
        this.submissionForm.get('to').setErrors({'required': true});
      } else if (data == 3) {
        this.submissionForm.get('description').clearValidators();
        this.submissionForm.get('to').clearValidators();
        this.submissionForm.get('description').setErrors(null);
        this.submissionForm.get('to').setErrors(null);
        this.submissionForm.get('description').updateValueAndValidity();
        this.submissionForm.get('to').updateValueAndValidity();
      }
    // }));
  }


  submitReview() {
    this.isSubmit = true;
    if (this.submissionForm.invalid) {
      return false;
    }
    const payload = {
      ...this.submissionForm.value,
      'to': (this.submissionForm.value.to).toLowerCase(),
      'cc': (this.submissionForm.value.cc).toLowerCase(),
      application_id: this.currentApplication.id
    }
    this.subscription.add(this.adminService.postSubmissionReview(payload).subscribe((data: any) => {
      if (this.submissionForm.value.decision == 3) {
        this.toasterService.success("Application accepted successfully");
      } else if (this.submissionForm.value.decision == 2) {
        this.toasterService.success("Application incompleted successfully");
      }
      this.getApplicationById();
      this.submissionForm.reset();
      this.initializeSubmissionForm();
      this.isSubmit = false;
    }));
  }

  voidApplication(item) {
    const payload = {
      id: item.id,
      application_id: this.currentApplication.id
    }
    this.subscription.add(this.adminService.voidSubmissionReview(payload).subscribe((data: any) => {
      this.toasterService.success("Void successfully");
      this.getApplicationById();
    }));
  }

  getApplicationById() {
    this.subscription.add(this.adminService.getApplicationById(this.currentApplication.id).subscribe(data => {
      this.adminService.setCurrentApplication(data);
    }));
  }

}
