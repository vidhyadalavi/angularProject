import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { AdminService } from 'src/app/core/services/admin/admin.service';

@Component({
  selector: 'app-application-detail',
  templateUrl: './application-detail.component.html',
  styleUrls: ['./application-detail.component.css']
})
export class ApplicationDetailComponent implements OnInit, OnDestroy {

  public application_id = '';
  public currentApplication = null;

  private subscription: Subscription = new Subscription();

  constructor(
    private adminService: AdminService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {

    this.activatedRoute.queryParams.subscribe(data => {
      this.application_id = data.id;
      if (!this.application_id) {
        this.router.navigate(['admin/index'], { queryParams: { type: 1 } });
      }
    });
    this.getApplicationById();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getApplicationById() {
    this.subscription.add(this.adminService.getApplicationById(this.application_id).subscribe(data => {
      this.currentApplication = data;
      this.adminService.setCurrentApplication(this.currentApplication);
    }));
  }



  goToIndex() {
    this.router.navigate(['admin/index'], { queryParams: { type: 1 } });
  }

}
