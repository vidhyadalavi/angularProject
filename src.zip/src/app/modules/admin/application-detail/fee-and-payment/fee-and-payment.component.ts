import { settingConfig } from 'src/app/configs';
import { Subscription } from 'rxjs';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminService } from 'src/app/core/services/admin/admin.service';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-fee-and-payment',
  templateUrl: './fee-and-payment.component.html',
  styleUrls: ['./fee-and-payment.component.css']
})
export class FeeAndPaymentComponent implements OnInit, OnDestroy {

  public currentApplication = null;
  public paymentList = [];
  public paymentForm: FormGroup;
  public isSubmit = false;
  public settingsConfig = settingConfig;
  public currentUser: any;

  private subscription: Subscription = new Subscription();

  constructor(private adminService: AdminService, private fb: FormBuilder, private authenticationService: AuthenticationService, private toasterService: ToastrService) { }

  ngOnInit() {
    this.subscription.add(this.authenticationService.getUserInfo().subscribe(user => {
      this.currentUser = user ? user : null;
    }));
    this.initializePaymentForm();
    this.getCurrentApplication();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getCurrentApplication() {
    this.subscription.add(this.adminService.getCurrentApplication().subscribe(data => {
      this.currentApplication = data;
      if (this.currentApplication) {
        this.paymentList = this.currentApplication.application_payment_data;
        if (this.paymentList && this.paymentList.length > 0) {
          this.paymentList.forEach((paymentObj, i) => {
            if (paymentObj.fee_type == 0 && !paymentObj.isFireFeeInitial) {
              if (this.currentApplication.type_of_permit == 3) {
                paymentObj.isFireFeeInitial = false;
                this.paymentList.splice(i + 1, 0, { ...paymentObj, isFireFeeInitial: true })
                // this.paymentList.push({...paymentObj, isFireFeeInitial: true});
              } else if (this.currentApplication.type_of_permit == 2) {
                paymentObj.isFireFeeInitial = true;
              } else if (this.currentApplication.type_of_permit == 1) {
                paymentObj.isFireFeeInitial = false;
              }
            }
            // console.log(this.paymentList);
          });
        }
      }
    }));
  }

  initializePaymentForm() {
    this.paymentForm = this.fb.group({
      payment_type: ['', [Validators.required]],
      fee_type: ['', [Validators.required]],
      amount: ['', [Validators.required]]
    });
  }

  submitPayment() {
    this.isSubmit = true;
    if (this.paymentForm.invalid) {
      return false;
    }
    const payload = {
      ...this.paymentForm.value,
      application_id: this.currentApplication.id
    }
    this.subscription.add(this.adminService.postPayment(payload).subscribe(data => {
      this.paymentList = data;
      if (this.paymentList && this.paymentList.length > 0) {
        this.paymentList.forEach((paymentObj, i) => {
          if (paymentObj.fee_type == 0 && !paymentObj.isFireFeeInitial) {
            if (this.currentApplication.type_of_permit == 3) {
              paymentObj.isFireFeeInitial = false;
              this.paymentList.splice(i + 1, 0, { ...paymentObj, isFireFeeInitial: true })
              // this.paymentList.push({...paymentObj, isFireFeeInitial: true});
            } else if (this.currentApplication.type_of_permit == 2) {
              paymentObj.isFireFeeInitial = true;
            } else if (this.currentApplication.type_of_permit == 1) {
              paymentObj.isFireFeeInitial = false;
            }
          }
          // console.log(this.paymentList);
        });
      }
      this.isSubmit = false;
      this.paymentForm.reset();
      this.paymentForm.get('payment_type').setValue('');
      this.paymentForm.get('fee_type').setValue('');
      this.paymentForm.get('amount').setValue('');
    }));
  }

  /*
  voidPayment(id) {
    const payload = {
      id,
      application_id: this.currentApplication.id
    };
    this.subscription.add(this.adminService.voidPayment(payload).subscribe(data => {
      this.paymentList = data;
    }));
  }
  */

  waiveOffFee(id, type) {
    const payload = {
      id,
      application_id: Number(this.currentApplication.id)
    }
    this.subscription.add(this.adminService.feeWaiveOff(payload).subscribe(data => {
      this.paymentList = data;
      if (this.paymentList && this.paymentList.length > 0) {
        this.paymentList.forEach((paymentObj, i) => {
          if (paymentObj.fee_type == 0 && !paymentObj.isFireFeeInitial) {
            if (this.currentApplication.type_of_permit == 3) {
              paymentObj.isFireFeeInitial = false;
              this.paymentList.splice(i + 1, 0, { ...paymentObj, isFireFeeInitial: true })
              // this.paymentList.push({...paymentObj, isFireFeeInitial: true});
            } else if (this.currentApplication.type_of_permit == 2) {
              paymentObj.isFireFeeInitial = true;
            } else if (this.currentApplication.type_of_permit == 1) {
              paymentObj.isFireFeeInitial = false;
            }
          }
          // console.log(this.paymentList);
        });
      }
      if (type == 1) {
        this.toasterService.success("Fee void successfully");
      } else if (type == 2) {
        this.toasterService.success("Fee waived off successfully");
      }
    }));
  }

  downloadReceipt(receiptUrl) {
    window.open(receiptUrl, '_blank');
  }



}
