import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { AdminService } from 'src/app/core/services/admin/admin.service';

@Component({
  selector: 'app-email-and-notes',
  templateUrl: './email-and-notes.component.html',
  styleUrls: ['./email-and-notes.component.css']
})
export class EmailAndNotesComponent implements OnInit, OnDestroy {

  public currentApplication = null;
  public currentTab = 1 //1-Email, 2-Notes
  public description = '';
  public emailForm: FormGroup;
  public isSubmit = false;
  public notesList = [];
  public emailList = [];

  private subscription: Subscription = new Subscription();

  constructor(private adminService: AdminService, private fb: FormBuilder) { }

  ngOnInit() {
    this.initializeEmailForm();
    this.getCurrentApplication();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  initializeEmailForm() {
    this.emailForm = this.fb.group({
      to: ['', [Validators.required, Validators.email]],
      cc: ['', [Validators.email]],
      subject: ['', [Validators.required]],
      description: ['', [Validators.required]]
    });
  }

  getCurrentApplication() {
    this.subscription.add(this.adminService.getCurrentApplication().subscribe(data => {
      this.currentApplication = data;
      if (data) {
        this.notesList = data.application_admin_note_data;
        this.emailList = data.application_admin_email_data;
        if (this.currentApplication && this.currentApplication.user_detail) {
          this.emailForm.controls.to.setValue(this.currentApplication.user_detail.email);
        }
      }
    }));
  }

  selectCurrentTab(tab) {
    this.currentTab = tab;
  }

  submitNote() {
    if (this.description == '') {
      return false;
    }
    const payload = {
      description: this.description,
      application_id: this.currentApplication.id
    };
    this.subscription.add(this.adminService.submitNote(payload).subscribe(data => {
      this.notesList = data;
      this.description = '';
    }));
  }

  submitEmail() {
    this.isSubmit = true;
    if (this.emailForm.invalid) {
      return false;
    };
    const payload = {
      ...this.emailForm.value,
      'to': (this.emailForm.value.to).toLowerCase(),
      'cc': (this.emailForm.value.cc).toLowerCase(),
      application_id: this.currentApplication.id
    }
    this.subscription.add(this.adminService.postEmail(payload).subscribe(data => {
      this.emailList = data;
      this.isSubmit = false
      this.emailForm.reset();
      this.emailForm.controls.to.setValue(this.currentApplication.user_detail.email);
    }));
  }

  deleteNote(id) {
    const payload = {
      id,
      application_id: this.currentApplication.id
    };
    this.subscription.add(this.adminService.deleteNote(payload).subscribe(data => {
      this.notesList = data;
    }));
  }

}
