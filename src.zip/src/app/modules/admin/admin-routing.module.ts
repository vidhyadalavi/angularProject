import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminAuthGuard } from 'src/app/core/guards/admin-auth.guard';
import { AdminIndexComponent } from './admin-index/admin-index.component';
import { AdminComponent } from './admin.component';
import { ApplicationDetailComponent } from './application-detail/application-detail.component';
import { AddCityAdminComponent } from './city-admin/add-city-admin/add-city-admin.component';
import { CityAdminComponent } from './city-admin/city-admin.component';
import { AddStaffComponent } from './staff/add-staff/add-staff.component';
import { StaffComponent } from './staff/staff.component';


const routes: Routes = [
  {
    path: '',
    component: AdminComponent,
    canActivate: [AdminAuthGuard],
    canActivateChild : [AdminAuthGuard],
    children : [
      {
        path: 'city-admin',
        component: CityAdminComponent
      },
      {
        path: 'add-city-admin',
        component: AddCityAdminComponent
      },
      {
        path: 'index',
        component: AdminIndexComponent
      },
      {
        path: 'staff',
        component: StaffComponent
      },
      {
        path: 'add-staff',
        component: AddStaffComponent
      },
      {
        path: 'application-detail',
        component: ApplicationDetailComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
