import { ToastrService } from 'ngx-toastr';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { settingConfig } from 'src/app/configs';
import { AuthenticationService } from 'src/app/core/authentication/authentication.service';
import { AdminService } from 'src/app/core/services/admin/admin.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-add-staff',
  templateUrl: './add-staff.component.html',
  styleUrls: ['./add-staff.component.css']
})
export class AddStaffComponent implements OnInit, OnDestroy {

  public staffForm: FormGroup;
  public isSubmit = false;
  public isActive = true;
  public editAdmin = null;
  public settingConfig = settingConfig;
  public currentAdmin = null;

  private subscription: Subscription = new Subscription();

  constructor(private fb: FormBuilder,
    private router: Router,
    private adminService: AdminService,
    private authenticationService: AuthenticationService,
    private toasterService: ToastrService) { }

  ngOnInit() {
    this.subscription.add(this.authenticationService.getUserInfo().subscribe(data => {
      if (data) {
        this.currentAdmin = data;
      }
    }));
    this.initializeStaffForm();
    this.editAdmin = this.adminService.getCurrentStaff();
    if (this.editAdmin) {
      this.patchFormValue();
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  initializeStaffForm() {
    this.staffForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      first_name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
      last_name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
      phone: ['', [Validators.required, Validators.minLength(14), Validators.maxLength(14)]],
      role: ['', [Validators.required]]
    });
  }

  patchFormValue() {
    this.staffForm.patchValue({
      email: this.editAdmin.email,
      first_name: this.editAdmin.first_name,
      last_name: this.editAdmin.last_name ? this.editAdmin.last_name : '',
      phone: this.editAdmin.phone ? this.editAdmin.phone : '',
      role: this.editAdmin.role
    });
    this.isActive = this.editAdmin.status === 1 ? true : false;
  }

  submitForm() {
    this.isSubmit = true;
    if (this.staffForm.invalid) {
      return false;
    }
    const payload = {
      ...this.staffForm.value,
      city: this.currentAdmin.city,
      cb_status: this.isActive ? 1 : 0,
      status: this.isActive ? 1 : 0,
    }
    if (this.editAdmin) {
      payload['id'] = this.editAdmin.id,
      payload['city_id'] = this.editAdmin.id,
      payload['cb_status'] = this.editAdmin.cb_status
    }
    this.subscription.add(this.adminService.addStaff(payload).subscribe(data => {
      if (this.editAdmin) {
        this.toasterService.success('Staff updated successfully');
      } else {
        this.toasterService.success('Staff added successfully');
      }
      this.router.navigate(['admin/staff']);
    }));
  }

  goToStaffIndex() {
    this.router.navigate(['admin/staff'])
  }

}
