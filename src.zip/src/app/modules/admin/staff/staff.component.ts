import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { AdminService } from 'src/app/core/services/admin/admin.service';
import { settingConfig } from 'src/app/configs';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css']
})
export class StaffComponent implements OnInit, OnDestroy {

  public settingsConfig = settingConfig;
  public staffList = [];
  public pagination = {
    page: 1,
    limit: 10,
    totalDocuments: 0
  }
  public search_query = '';
  public showPassword = false;
  public staffPasswordResetForm: FormGroup;
  public isSubmit = false;
  public selectedStaffEmail: String;

  @ViewChild('closeStaffModal', {static : false}) private closeStaffModal: ElementRef;

  private subscription: Subscription = new Subscription();

  constructor(private router: Router, private adminService: AdminService, private toasterService: ToastrService, private fb: FormBuilder) { }

  ngOnInit() {
    this.adminService.removeCurrentStaff();
    this.getStaffList(this.pagination);
    this.initializeStaffResetPasswordForm();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  navigateToAddNewStaffPage() {
    this.router.navigate(['admin/add-staff'])
  }

  getStaffList(pagination) {
    this.subscription.add(this.adminService.getAdminStaff(pagination).subscribe(data => {
      this.staffList = data.response;
      this.pagination.page = data.page;
      this.pagination.limit = data.limit;
      this.pagination.totalDocuments = data.totalDocuments;
    }));
  }

  resendStaffLink(id) {
    this.subscription.add(this.adminService.resendStaffLink({ id }).subscribe(data => {
    }));
  }

  paginate(page) {
    this.pagination['page'] = page;
    this.getStaffList(this.pagination);
  }

  editAdminStaff(item) {
    this.adminService.setCurrentStaff(item);
    this.router.navigate(['admin/add-staff']);
  }

  goToIndex() {
    this.router.navigate(['admin/index'], { queryParams: { type: 1 } });
  }

  searchApplication() {
    this.pagination['search_query'] = this.search_query;
    this.pagination['page'] = 1;
    this.getStaffList(this.pagination);
  }

  showAndHidePassword(showPassword) {
    if (showPassword) {
      this.showPassword = false;
    } else if (!showPassword) {
      this.showPassword = true;
    }
  }

  resetPassword() {
    this.isSubmit = true;

    if (this.staffPasswordResetForm.invalid) {
      return false;
    }
    const payload = {
        email: this.selectedStaffEmail,
        ...this.staffPasswordResetForm.value
    };
    this.subscription.add(this.adminService.cityAdminStaffResetPassword(payload).subscribe((data: any) => {
        this.isSubmit = false;
        this.selectedStaffEmail = '';
        this.toasterService.success("Password reset successfull");
        this.closeStaffModal.nativeElement.click();
    }));
  }

  initializeStaffResetPasswordForm() {
    this.staffPasswordResetForm = this.fb.group({
      password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(30)]],
      cnfPassword: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(30)]]
    });
  }

  setSelectedStaffEmail(staffEmail) {
    this.selectedStaffEmail = staffEmail;
    this.staffPasswordResetForm.reset();
    this.initializeStaffResetPasswordForm();
    this.isSubmit = false;
    this.showPassword = false;
  }

  checkPasswordMatch() {
    let password = this.staffPasswordResetForm.get('password').value;
    let cnfPassword = this.staffPasswordResetForm.get('cnfPassword').value;
    if (password == cnfPassword) {
      this.staffPasswordResetForm.get('cnfPassword').setErrors(null);
      this.staffPasswordResetForm.get('cnfPassword').clearValidators();
      return true
    } else {
      this.staffPasswordResetForm.get('cnfPassword').setErrors({ invalid: true });
      return false;
    }
  }

  get password() { return this.staffPasswordResetForm.get('password') }
  get cnfPassword() { return this.staffPasswordResetForm.get('cnfPassword') }

}
