import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AchAccountService {

  constructor(private http: HttpClient) { }

  addACHAccount(data): Observable<any> {
    const url = `${environment.addACHAccount}`;
    return this.http.post<any>(url, data).pipe(
      tap(
        (data) => {
          if (data.status === 'success') {
            return data;
          }
        }
      )
    );
  }

  verifyACHAccount(data): Observable<any> {
    const url = `${environment.verifyACHAccount}`;
    return this.http.post<any>(url, data).pipe(
      tap(
        (data) => {
          if (data.status === 'success') {
          }
          return data;
        }
      )
    );
  }

  deleteACHAccount(data): Observable<any> {
    const url = `${environment.deleteACHAccount}`;
    return this.http.post<any>(url, data).pipe(
      tap(
        (data) => {
          if (data.status === 'success') {
          }
          return data;
        }
      )
    );
  }

  getACHAccountList(application_id): Observable<any> {
    const url = `${environment.achAccountList}`;
    return this.http.get<any>(url, {params: {application_id}}).pipe(
      map(
        ({ status, ...rest }) => {
          if (status === 'success') {
          }
          return rest;
        }
      )
    );
  }

  getACHAccountListIndex(): Observable<any> {
    const url = `${environment.achAccountListIndex}`;
    return this.http.get<any>(url).pipe(
      map(
        ({ status, ...rest }) => {
          if (status === 'success') {
          }
          return rest;
        }
      )
    );
  }

  getACHAccount(query): Observable<any> {
    const url = `${environment.getACHAccount}`;
    return this.http.get<any>(url,{params:query}).pipe(
      map(
        ({ status, ...rest }) => {
          if (status === 'success') {
          }
          return rest;
        }
      )
    );
  }
}
