import { ApplicationService } from 'src/app/core/http/users/application.service';
import { AuthenticationService } from './../../../authentication/authentication.service';
import { NavigationEnd, Router } from '@angular/router';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { appToaster } from 'src/app/configs';
import { UsersService } from 'src/app/core/services';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit, OnDestroy {
  public currentUser;
  public isApplicationEditable = false;
  public isFormActive = false;
  private subscription: Subscription = new Subscription();
  public activeRoute: any;
  public currentApplication = null;
  public showSaveAndExit = false;

  constructor(
    private router: Router,
    public authenticationService: AuthenticationService,
    private toasterService: ToastrService,
    private userService: UsersService,
    private applicationService: ApplicationService
  ) {

    /** GET CURRENT ROUTE */

    this.subscription.add(this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        this.currentApplication = this.userService.getCurrentApplication();
        this.activeRoute = event.url.split('/')
        if (this.activeRoute[3] && this.activeRoute[3].includes('what') && (!this.currentApplication)) {
          this.showSaveAndExit = false;
        } else if ((this.currentApplication && (this.currentApplication.response.id)) && (this.activeRoute[3] && (this.activeRoute[3].includes('what')))) {
          this.showSaveAndExit = true;
        } else if ((this.activeRoute[3] && (!this.activeRoute[3].includes('what')))) {
          this.showSaveAndExit = true;
        } else if ((this.activeRoute[3] && (this.activeRoute[3].includes('what'))) && this.currentApplication && (!this.currentApplication.response.id)) {
          this.showSaveAndExit = false;
        }
        if (this.activeRoute[2] == 'application' && (!this.activeRoute[this.activeRoute.length - 1].includes('payment'))) {
          this.isFormActive = true;
        } else {
          this.isFormActive = false;
        }
      }
    }));
  }

  ngOnInit() {
    this.subscription.add(this.userService.userDetailsObs.subscribe((data: any) => {
      if (data) {
        this.currentUser = data ? data : null;
      } else {
        if (this)
          this.subscription.add(this.authenticationService.getUserInfo().subscribe(user => {
            this.currentUser = user ? user : null;
          })
          );
      }
    }));
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  goToLogin() {
    this.router.navigateByUrl('auth/sign-in');
  }

  onClickProfile() {
    this.router.navigateByUrl('user/update-profile');
  }

  onClickLogout() {
    this.authenticationService.logout();
    this.toasterService.success(appToaster.logoutSuccess);
    this.goToLogin();
  }

  onClickSaveAndExit() {
    let count = 0;
    let loopCount = 0;
    let whatFormPermit = this.applicationService.getWhatFormData() ? this.applicationService.getWhatFormData()['permit'] : '';
    let fireInstallerFormValid = this.applicationService.getFireInstallerForm();
    let burglarInstallerFormValid = this.applicationService.getBurglarInstallerForm();
    if (whatFormPermit) {
      if (this.currentApplication && whatFormPermit == 3 && this.currentApplication.response.application_installer_details && this.currentApplication.response.application_installer_details.length > 0 && (this.currentApplication.response.application_installer_details[0].installation_date == null || this.currentApplication.response.application_installer_details[1].installation_date == null)) {
        this.toasterService.error('Please fill both installer details');
      } else if (this.currentApplication && whatFormPermit == 1 && this.currentApplication.response.application_installer_details && this.currentApplication.response.application_installer_details.length > 0) {
        this.currentApplication.response.application_installer_details.forEach((installerObj) => {
          loopCount++;
          if (installerObj.installer_type == 1 && installerObj.installation_date == null) {
            this.toasterService.error('Please fill burglar installer details');
            count++;
          }
          if (loopCount == this.currentApplication.response.application_installer_details.length && count == 0) {
            if (this.activeRoute[this.activeRoute.length - 1] == 'review') {
              this.router.navigate(['user/index']);
            } else {
              this.applicationService.setSaveAndExit(true);
              this.userService.isSaveAndExit.next({ isSaveAndExit: true, currentForm: this.activeRoute[this.activeRoute.length - 1] });;
            }
          }
        });
      } else if (this.currentApplication && whatFormPermit == 2 && this.currentApplication.response.application_installer_details && this.currentApplication.response.application_installer_details.length > 0) {
        this.currentApplication.response.application_installer_details.forEach((installerObj) => {
          loopCount++;
          if (installerObj.installer_type == 2 && installerObj.installation_date == null) {
            this.toasterService.error('Please fill fire installer details');
            count++;
          }
          if (loopCount == this.currentApplication.response.application_installer_details.length && count == 0) {
            if (this.activeRoute[this.activeRoute.length - 1] == 'review') {
              this.router.navigate(['user/index']);
            } else {
              this.applicationService.setSaveAndExit(true);
              this.userService.isSaveAndExit.next({ isSaveAndExit: true, currentForm: this.activeRoute[this.activeRoute.length - 1] });;
            }
          }
        });
      } else {
        if (this.activeRoute[this.activeRoute.length - 1] == 'review') {
          this.router.navigate(['user/index']);
        } else {
          this.applicationService.setSaveAndExit(true);
          this.userService.isSaveAndExit.next({ isSaveAndExit: true, currentForm: this.activeRoute[this.activeRoute.length - 1] });;
        }
      }
    } else {
      if (this.currentApplication && this.currentApplication.response.type_of_permit == 3 && this.currentApplication.response.application_installer_details && this.currentApplication.response.application_installer_details.length > 0 && (this.currentApplication.response.application_installer_details[0].installation_date == null || this.currentApplication.response.application_installer_details[1].installation_date == null)) {
        if (fireInstallerFormValid === false || burglarInstallerFormValid === false) {
          this.toasterService.error('Please fill both installer details');
        } else if (this.activeRoute[this.activeRoute.length - 1] == 'review') {
          this.router.navigate(['user/index']);
        } else {
          this.applicationService.setSaveAndExit(true);
          this.userService.isSaveAndExit.next({ isSaveAndExit: true, currentForm: this.activeRoute[this.activeRoute.length - 1] });;
        }
      } else if (this.currentApplication && this.currentApplication.response.type_of_permit == 1 && this.currentApplication.response.application_installer_details && this.currentApplication.response.application_installer_details.length > 0) {
        this.currentApplication.response.application_installer_details.forEach((installerObj) => {
          loopCount++;
          if ((burglarInstallerFormValid === false) && installerObj.installer_type == 1 && installerObj.installation_date == null) {
            this.toasterService.error('Please fill burglar installer details');
            count++;
          }
          if (loopCount == this.currentApplication.response.application_installer_details.length && (count == 0)) {
            if (this.activeRoute[this.activeRoute.length - 1] == 'review') {
              this.router.navigate(['user/index']);
            } else {
              this.applicationService.setSaveAndExit(true);
              this.userService.isSaveAndExit.next({ isSaveAndExit: true, currentForm: this.activeRoute[this.activeRoute.length - 1] });;
            }
          }
        });
      } else if (this.currentApplication && this.currentApplication.response.type_of_permit == 2 && this.currentApplication.response.application_installer_details && this.currentApplication.response.application_installer_details.length > 0) {
        this.currentApplication.response.application_installer_details.forEach((installerObj) => {
          loopCount++;
          if ((fireInstallerFormValid === false) && installerObj.installer_type == 2 && installerObj.installation_date == null) {
            this.toasterService.error('Please fill fire installer details');
            count++;
          }
          if (loopCount == this.currentApplication.response.application_installer_details.length && (count == 0)) {
            if (this.activeRoute[this.activeRoute.length - 1] == 'review') {
              this.router.navigate(['user/index']);
            } else {
              this.applicationService.setSaveAndExit(true);
              this.userService.isSaveAndExit.next({ isSaveAndExit: true, currentForm: this.activeRoute[this.activeRoute.length - 1] });;
            }
          }
        });
      } else {
        if (this.activeRoute[this.activeRoute.length - 1] == 'review') {
          this.router.navigate(['user/index']);
        } else {
          this.applicationService.setSaveAndExit(true);
          this.userService.isSaveAndExit.next({ isSaveAndExit: true, currentForm: this.activeRoute[this.activeRoute.length - 1] });;
        }
      }
    }

  }

  navigateToIndexPage() {
    this.router.navigate(['user/index']);
  }

  onClickACHAccount() {
    this.router.navigate(['user/ach/index']);
  }

  navigateToPaymentPage() {
    let count = 0;
    let loopCount = 0;
    if (this.currentApplication && this.currentApplication.response.type_of_permit == 3 && this.currentApplication.response.application_installer_details.length > 0 && (this.currentApplication.response.application_installer_details[0].installation_date == null || this.currentApplication.response.application_installer_details[1].installation_date == null)) {
      this.toasterService.error('Please fill both installer details');
    } else if (this.currentApplication && this.currentApplication.response.type_of_permit == 1 && this.currentApplication.response.application_installer_details.length > 0) {
      this.currentApplication.response.application_installer_details.forEach((installerObj) => {
        loopCount++;
        if (installerObj.installer_type == 1 && installerObj.installation_date == null) {
          this.toasterService.error('Please fill burglar installer details');
          count++;
        }
        if (loopCount == this.currentApplication.response.application_installer_details.length && count == 0) {
          this.router.navigate(['user/application/payment'], { queryParams: { applicationId: this.currentApplication.response.id, feeType: this.checkFeeType(this.currentApplication.response) } });
        }
      });
    } else if (this.currentApplication && this.currentApplication.response.type_of_permit == 2 && this.currentApplication.response.application_installer_details.length > 0) {
      this.currentApplication.response.application_installer_details.forEach((installerObj) => {
        loopCount++;
        if (installerObj.installer_type == 2 && installerObj.installation_date == null) {
          this.toasterService.error('Please fill fire installer details');
          count++;
        }
        if (loopCount == this.currentApplication.response.application_installer_details.length && count == 0) {
          this.router.navigate(['user/application/payment'], { queryParams: { applicationId: this.currentApplication.response.id, feeType: this.checkFeeType(this.currentApplication.response) } });
        }
      });
    } else {
      this.router.navigate(['user/application/payment'], { queryParams: { applicationId: this.currentApplication.response.id, feeType: this.checkFeeType(this.currentApplication.response) } });
    }
  }

  checkFeeType(application) {
    if (application.application_payment_data && application.application_payment_data.length > 0) {
      application.application_payment_data.forEach((element) => {
        if (element.fee_type == 0 && element.status == 3) {
          return 1;
        } else if (element.fee_type == 0 && (element.status == 0 || element.status == null)) {
          return 0;
        }
      });
    } else {
      return 0;
    }
  }

  switchToOtherPortal(val) {
    this.authenticationService.logout();
    const csrfToken = sessionStorage.getItem('csrfToken');
    if (val == 1) {
      window.open(`${environment.cannabisUrl}user/index?csrfToken=${csrfToken}`, '_self');
    } else if (val == 2) {
      window.open(`${environment.tradeWasteUrl}user/index?csrfToken=${csrfToken}`, '_self');
    }
  }


}
