export interface OccupancyApplication {

}
