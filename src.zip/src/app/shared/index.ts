/**
 * SHARED MODULES
 * 1. ALL THE SHARED MODELS
 *  - 1. LOGIN MODEL
 *  - 2. REGISTER MODEL
 */

export * from './models/index'
