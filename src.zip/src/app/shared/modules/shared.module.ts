import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormatPhoneNumberDirective } from '../directives/format-phone-number.directive';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OnlyNumberDirective } from '../directives/only-number.directive';
import { GoogleAddressDirective } from '../directives/google-address.directive';

@NgModule({
  declarations: [
    FormatPhoneNumberDirective,
    OnlyNumberDirective,
    GoogleAddressDirective
  ],
  imports: [
    CommonModule,
    BsDatepickerModule.forRoot(),
  ],
  exports: [
    FormatPhoneNumberDirective,
    BsDatepickerModule,
    OnlyNumberDirective,
    GoogleAddressDirective
  ]
})
export class SharedModule { }
