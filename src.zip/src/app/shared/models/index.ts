/**
 * SHARED MODELS
 * 1. LOGIN MODEL CONTAINS ALL THE INFORMATION NEEDED
 * 2. REGISTER MODEL CONTAINS ALL THE INFORMATION NEEDED FOR REGISTER
 */

export * from './login.model';
export * from './register.model';
