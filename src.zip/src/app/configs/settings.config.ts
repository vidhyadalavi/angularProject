export const settingConfig = {

  applicationTab: [
    {
      key: 'What',
      value: 1
    },
    {
      key: 'Where',
      value: 2
    },
    {
      key: 'Alarm Holder',
      value: 3
    },
    {
      key: 'Installer',
      value: 4
    },
    {
      key: 'Premises',
      value: 5
    },
    {
      key: 'Point Of Contact',
      value: 6
    },
  ],
  what: {
    typeOfWhat: [
      {
        key: 'New',
        value: 1
      },
      {
        key: 'Renewal',
        value: 2
      }
    ],
    typeOfPermit: [
      {
        key: 'Burglar only',
        value: 1
      },
      {
        key: 'Fire only',
        value: 2
      },
      {
        key: 'Both',
        value: 3
      }
    ],
    typeOfAlarm: [
      {
        key: 'Central Station',
        value: 1
      },
      {
        key: 'Telephone Alarm',
        value: 2
      },
      {
        key: 'Outside Alarm',
        value: 3
      }
    ]
  },
  where: {
    locationType: [
      {
        key: 'Residential 1-3 Units',
        value: 1
      },
      {
        key: 'Residential 4 + Units',
        value: 2
      },
      {
        key: 'Apartment/Condo/Coop',
        value: 3
      },
      {
        key: 'Store',
        value: 4
      },
      {
        key: 'Factory',
        value: 5
      },
      {
        key: 'Warehouse',
        value: 6
      },
      {
        key: 'Hospital',
        value: 7
      },
      {
        key: 'School',
        value: 8
      },
      {
        key: 'Tavern',
        value: 9
      },
      {
        key: 'Restaurant',
        value: 10
      },
      {
        key: 'Office Building',
        value: 11
      },
      {
        key: 'Church',
        value: 12
      },
    ],
    businessLicenseAnswerOptions: [
      {
        key: 'Yes',
        value: 1
      },
      {
        key: 'No',
        value: 2
      }
    ]
  },
  installer: {
    answerOptions: [
      {
        key: 'Yes',
        value: 1
      },
      {
        key: 'No',
        value: 2
      }
    ]
  },
  premises: {
    answerOptions: [
      {
        key: 'Yes',
        value: 1
      },
      {
        key: 'No',
        value: 2
      }
    ]
  },
  pointOfContacts: [
    {
      point_of_contact: '',
      title: '',
      primary_phone: '',
      alternate_phone: ''
    },
    {
      point_of_contact: '',
      title: '',
      primary_phone: '',
      alternate_phone: ''
    },
    {
      point_of_contact: '',
      title: '',
      primary_phone: '',
      alternate_phone: ''
    }
  ],
  statesOfUS: [
    "Alaska",
    "Alabama",
    "Arkansas",
    "American Samoa",
    "Arizona",
    "California",
    "Colorado",
    "Connecticut",
    "District of Columbia",
    "Delaware",
    "Florida",
    "Georgia",
    "Guam",
    "Hawaii",
    "Iowa",
    "Idaho",
    "Illinois",
    "Indiana",
    "Kansas",
    "Kentucky",
    "Louisiana",
    "Massachusetts",
    "Maryland",
    "Maine",
    "Michigan",
    "Minnesota",
    "Missouri",
    "Mississippi",
    "Montana",
    "North Carolina",
    "North Dakota",
    "Nebraska",
    "New Hampshire",
    "New Jersey",
    "New Mexico",
    "Nevada",
    "New York",
    "Ohio",
    "Oklahoma",
    "Oregon",
    "Pennsylvania",
    "Puerto Rico",
    "Rhode Island",
    "South Carolina",
    "South Dakota",
    "Tennessee",
    "Texas",
    "Utah",
    "Virginia",
    "Virgin Islands",
    "Vermont",
    "Washington",
    "Wisconsin",
    "West Virginia",
    "Wyoming"
  ],
  citiesOfUS: [
    "Aberdeen", "Abilene", "Akron", "Albany", "Albuquerque", "Alexandria", "Allentown", "Amarillo", "Anaheim", "Anchorage", "Ann Arbor", "Antioch", "Apple Valley", "Appleton", "Arlington", "Arvada", "Asheville", "Athens", "Atlanta", "Atlantic City", "Augusta", "Aurora", "Austin", "Bakersfield", "Baltimore", "Barnstable", "Baton Rouge", "Beaumont", "Bel Air", "Bellevue", "Berkeley", "Bethlehem", "Billings", "Birmingham", "Bloomington", "Boise", "Boise City", "Bonita Springs", "Boston", "Boulder", "Bradenton", "Bremerton", "Bridgeport", "Brighton", "Brownsville", "Bryan", "Buffalo", "Burbank", "Burlington", "Cambridge", "Canton", "Cape Coral", "Carrollton", "Cary", "Cathedral City", "Cedar Rapids", "Champaign", "Chandler", "Charleston", "Charlotte", "Chattanooga", "Chesapeake", "Chicago", "Chula Vista", "Cincinnati", "Clarke County", "Clarksville", "Clearwater", "Cleveland", "College Station", "Colorado Springs", "Columbia", "Columbus", "Concord", "Coral Springs", "Corona", "Corpus Christi", "Costa Mesa", "Dallas", "Daly City", "Danbury", "Davenport", "Davidson County", "Dayton", "Daytona Beach", "Deltona", "Denton", "Denver", "Des Moines", "Detroit", "Downey", "Duluth", "Durham", "El Monte", "El Paso", "Elizabeth", "Elk Grove", "Elkhart", "Erie", "Escondido", "Eugene", "Evansville", "Fairfield", "Fargo", "Fayetteville", "Fitchburg", "Flint", "Fontana", "Fort Collins", "Fort Lauderdale", "Fort Smith", "Fort Walton Beach", "Fort Wayne", "Fort Worth", "Frederick", "Fremont", "Fresno", "Fullerton", "Gainesville", "Garden Grove", "Garland", "Gastonia", "Gilbert", "Glendale", "Grand Prairie", "Grand Rapids", "Grayslake", "Green Bay", "GreenBay", "Greensboro", "Greenville", "Gulfport-Biloxi", "Hagerstown", "Hampton", "Harlingen", "Harrisburg", "Hartford", "Havre de Grace", "Hayward", "Hemet", "Henderson", "Hesperia", "Hialeah", "Hickory", "High Point", "Hollywood", "Honolulu", "Houma", "Houston", "Howell", "Huntington", "Huntington Beach", "Huntsville", "Independence", "Indianapolis", "Inglewood", "Irvine", "Irving", "Jackson", "Jacksonville", "Jefferson", "Jersey City", "Johnson City", "Joliet", "Kailua", "Kalamazoo", "Kaneohe", "Kansas City", "Kennewick", "Kenosha", "Killeen", "Kissimmee", "Knoxville", "Lacey", "Lafayette", "Lake Charles", "Lakeland", "Lakewood", "Lancaster", "Lansing", "Laredo", "Las Cruces", "Las Vegas", "Layton", "Leominster", "Lewisville", "Lexington", "Lincoln", "Little Rock", "Long Beach", "Lorain", "Los Angeles", "Louisville", "Lowell", "Lubbock", "Macon", "Madison", "Manchester", "Marina", "Marysville", "McAllen", "McHenry", "Medford", "Melbourne", "Memphis", "Merced", "Mesa", "Mesquite", "Miami", "Milwaukee", "Minneapolis", "Miramar", "Mission Viejo", "Mobile", "Modesto", "Monroe", "Monterey", "Montgomery", "Moreno Valley", "Murfreesboro", "Murrieta", "Muskegon", "Myrtle Beach", "Naperville", "Naples", "Nashua", "Nashville", "New Bedford", "New Haven", "New London", "New Orleans", "New York", "New York City", "Newark", "Newburgh", "Newport News", "Norfolk", "Normal", "Norman", "North Charleston", "North Las Vegas", "North Port", "Norwalk", "Norwich", "Oakland", "Ocala", "Oceanside", "Odessa", "Ogden", "Oklahoma City", "Olathe", "Olympia", "Omaha", "Ontario", "Orange", "Orem", "Orlando", "Overland Park", "Oxnard", "Palm Bay", "Palm Springs", "Palmdale", "Panama City", "Pasadena", "Paterson", "Pembroke Pines", "Pensacola", "Peoria", "Philadelphia", "Phoenix", "Pittsburgh", "Plano", "Pomona", "Pompano Beach", "Port Arthur", "Port Orange", "Port Saint Lucie", "Port St. Lucie", "Portland", "Portsmouth", "Poughkeepsie", "Providence", "Provo", "Pueblo", "Punta Gorda", "Racine", "Raleigh", "Rancho Cucamonga", "Reading", "Redding", "Reno", "Richland", "Richmond", "Richmond County", "Riverside", "Roanoke", "Rochester", "Rockford", "Roseville", "Round Lake Beach", "Sacramento", "Saginaw", "Saint Louis", "Saint Paul", "Saint Petersburg", "Salem", "Salinas", "Salt Lake City", "San Antonio", "San Bernardino", "San Buenaventura", "San Diego", "San Francisco", "San Jose", "Santa Ana", "Santa Barbara", "Santa Clara", "Santa Clarita", "Santa Cruz", "Santa Maria", "Santa Rosa", "Sarasota", "Savannah", "Scottsdale", "Scranton", "Seaside", "Seattle", "Sebastian", "Shreveport", "Simi Valley", "Sioux City", "Sioux Falls", "South Bend", "South Lyon", "Spartanburg", "Spokane", "Springdale", "Springfield", "St. Louis", "St. Paul", "St. Petersburg", "Stamford", "Sterling Heights", "Stockton", "Sunnyvale", "Syracuse", "Tacoma", "Tallahassee", "Tampa", "Temecula", "Tempe", "Thornton", "Thousand Oaks", "Toledo", "Topeka", "Torrance", "Trenton", "Tucson", "Tulsa", "Tuscaloosa", "Tyler", "Utica", "Vallejo", "Vancouver", "Vero Beach", "Victorville", "Virginia Beach", "Visalia", "Waco", "Warren", "Washington", "Waterbury", "Waterloo", "West Covina", "West Valley City", "Westminster", "Wichita", "Wilmington", "Winston", "Winter Haven", "Worcester", "Yakima", "Yonkers", "York", "Youngstown"
  ],

  adminRole: [
    // {
    //   key: 'Super Admin',
    //   value: 1
    // },
    // {
    //   key: 'City Admin',
    //   value: 2
    // },
    {
      key: 'Manager',
      value: 3
    },
    {
      key: 'Clerk',
      value: 4
    },
    // {
    //   key: 'Inspector',
    //   value: 5
    // },
    // {
    //   key: 'Technical review',
    //   value: 6
    // },
    // {
    //   key: 'Final review',
    //   value: 7
    // },
    // {
    //   key: 'Engineer',
    //   value: 8
    // },
    // {
    //   key: 'Assessor',
    //   value: 9
    // },
    // {
    //   key: 'Taxes',
    //   value: 10
    // },
    // {
    //   key: 'Board Member',
    //   value: 11
    // },
    {
      key: 'Alert',
      value: 6
    },
  ],
  application: {
    status: [
      {
        key: 'Draft',
        value: null, // 0
        name: 'draft'
      },
      {
        key: 'Draft',
        value: 0, // null
        name: 'draft'
      },
      {
        key: 'Complete',
        value: '1', //  by user
        name: 'complete'
      },
      {
        key: 'Incomplete',
        value: '2', // by admin
        name: 'incomplete'
      },
      {
        key: 'Accepted',
        value: '3', // complete by admin
        name: 'accepted'
      },
      {
        key: 'Submitted',
        value: '4', // submitted by user after payment
        name: 'submitted'
      },
      {
        key: 'Issued',
        value: '5', // by admin
        name: 'issued'
      },
    ],
  },

  ach: {
    country: 'US',
    currency: 'usd',
    account_holder_type: 'individual',
  },

  submission: {
    status: [
      {
        key: 'Accepted',
        value: 3
      },
      {
        key: 'Incomplete',
        value: 2
      },
    ]
  },

  feeAndPayment: {
    paymentType: [
      {
        key: 'Application',
        value: null
      },
      {
        key: 'Registration',
        value: 1
      },
      {
        key: 'Permit',
        value: 2
      }
    ],
    feeType: [
      {
        key: 'Initial',
        value: 0
      },
      {
        key: 'Burglar',
        value: 1
      },
      {
        key: 'Fire',
        value: 2
      },
      {
        key: 'Processing',
        value: 3
      },
    ],
  },

  payment: {
    status: [
      {
        key: 'Not Paid',
        value: null
      },
      {
        key: 'Not Paid',
        value: 0
      },
      {
        key: 'Pending',
        value: 1
      },
      {
        key: 'Failed',
        value: 2
      },
      {
        key: 'Success',
        value: 3
      },
      {
        key: 'Waived Off',
        value: 4
      },
      {
        key: 'Void',
        value: 5
      },
    ]
  },
  getKeysByName(formType, formField, formFieldValue) {
    let key = ''
    if (formField != '') {
      settingConfig[formType][formField].forEach(ele => {
        if (ele.value == formFieldValue) {
          key = ele.key;
        }
      });
      return key;
    } else if (formField == '') {
      settingConfig[formType].forEach(ele => {
        if (ele.value == formFieldValue) {
          key = ele.key;
        }
      });
      return key;
    }
  }

}


