/**
 * All the Config file endpoint
 * 1. settings.config consists of all the references of the enums
 */
export * from './settings.config';
export * from './toaster.config'
